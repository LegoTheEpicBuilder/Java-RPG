import java.util.Random;
import java.util.Scanner;
public class Speler
{
    private String name = "Unknown";
    private String weapon = "Fists";
    private int amountOfLives = 100;
    private Vijand vijand;
    private int averageDamage = 15;
    private int damageThisRound = 0;
    private boolean isDead = false;
    private double critChance;
    private Vijand huidigeVijand;
    
    Random rnd = new Random();
    
    public Speler(String name, String weapon, int amountOfLives){
        this.name = name;
        this.weapon = weapon;
        this.amountOfLives = amountOfLives;
    }
    public Speler(String name) {
        this.name = name;
    }
    
    public void chooseEnemy(Vijand vijand){
        this.vijand = vijand;
        huidigeVijand = vijand;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            vijand.choosePlayer(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public boolean isDead(){
        if (amountOfLives <= 0){
            isDead = true;
        }
        return isDead;
    }
    public void setAmountOfLives(int aantalLevens){
        this.amountOfLives = aantalLevens;
    }
    public int getAmountOfLives(){
        return amountOfLives;
    }
    public Vijand huidigeVijand(){
        return huidigeVijand;
    }
    public String checkWeapon(){
        if (weapon.equals("Wooden Club")){
            averageDamage = 25;
            critChance = 15;
        }
        if (weapon.equals("Sword")){
            averageDamage = 35;
            critChance = 5;
        }
        if (weapon.equals("Knife")){
            averageDamage = 30;
            critChance = 7;
        }
        if (weapon.equals("Fists")){
            averageDamage = 15;
            critChance = 10;
        }
        return weapon;
    }
    public void attack(){
        damageThisRound = calculateDamage();
        
        isDead();
        if (!isDead && !vijand.isDood()){
            vijand.setAantalLevens(vijand.getAantalLevens() - damageThisRound);
            if(vijand.getAantalLevens() < 0){
                vijand.setAantalLevens(0);           
            }
        }
        printDamageThisRound();
        // Hier valt de speler aan en wordt de vijand schade toegebracht
    }
    private int calculateDamage(){
        //normal damage
        int maxDmg = averageDamage + 5;
        int minDmg = averageDamage - 5;
        int getal = rnd.nextInt(11);
        
        damageThisRound = 0;
        
        checkWeapon();
        
        //crit damage
        int getal2 = rnd.nextInt(100) + 1;
        double damageMultiplier = 1;
        
        if (critChance >= getal2){
            damageMultiplier = 1.5;
            System.out.println("Crit!");
        }
        
        if (getal < 5){
            damageThisRound = (int) Math.round((averageDamage - (getal + 1)) * damageMultiplier);
        }
        else if (getal > 5){
            damageThisRound = (int) Math.round((averageDamage + getal - 5) * damageMultiplier);
        }
        else if (getal == 5){
            damageThisRound = (int) Math.round(averageDamage * damageMultiplier);
        }
        
        return damageThisRound;
    }
    public String getName(){
        return name;
    }
    public void printDamageThisRound(){
        System.out.println(name + " did do " + damageThisRound + " damage to " + vijand.getName() + " this round. ");
    }
}
// so the game now is just very simple. There is a player and an enemy.
// you can choose an enemy to fight and then attack him. After you attacked
// he will attack you. WIP.