import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;

public class Vijand
{
    static String[] kindsOfEnemies = {"Wolf","Wizard","Goblin","Zombie"};
    static String[] allAttacks = {"Claws", "Roar", "Spell", "Healing Drink", "Punch", "Gold Steal", "Bite", "Grab"};
    
    static String[] possibleNames = {"James", "Robert", "John", "Michael", "David", "William", 
                                "Mary", "Patricia", "Jennifer", "Linda", "Lisa"};
    
    private String naam = "Unknown";
    private String wapen = "Handen";
    
    //TBA
    private String attack1 = "?";
    private String attack2 = "?";
    private int averageDamage1 = 0;
    private int averageDamage2 = 0;
    
    private double critChance;
    
    private int aantalLevens = 100;
    private boolean isDood = false;
    private Speler speler;
    private int gemiddeldeSchade = 15;
    private int schadeDezeRonde;
    private String kindOfEnemy;
    private Speler huidigeSpeler;
    
    Random rnd = new Random();
    
    public Vijand(String kindOfEnemy, int aantalLevens){
        this.kindOfEnemy = kindOfEnemy;
        this.aantalLevens = aantalLevens;
        determineName();
    }
    public void choosePlayer(Speler speler){
        this.speler = speler;
        huidigeSpeler = speler;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            speler.chooseEnemy(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public boolean isDood(){
        if (aantalLevens <= 0){
            isDood = true;
        }
        return isDood;
    }
    public String checkWapen(){
        if (wapen.equals("Houten Knuppel")){
            gemiddeldeSchade = 25;
        }
        if (wapen.equals("Zwaard")){
            gemiddeldeSchade = 35;
        }
        if (wapen.equals("Mes")){
            gemiddeldeSchade = 30;
        }
        if (wapen.equals("Handen")){
            gemiddeldeSchade = 15;
        }
        return wapen;
    }
    public void checkEnemyAttacks(){
        //zet desbetreffende aanvallen gelijk aan de soort vijand
        for (int i = 0; i < kindsOfEnemies.length * 2 + 1; i+= 2){
            if (kindsOfEnemies[i / 2] == getKindOfEnemy()){
                attack1 = allAttacks[i];
                attack2 = allAttacks[i + 1];
                break;
            }
        }
    }
    public void checkEnemyAttacks2(){   
        //voor primary attacks
        for (int i = 0; i < allAttacks.length; i += 2){
            if (attack1.equals(allAttacks[i])){
                switch(i){
                    case 0:
                        averageDamage1 = 20;    //Claws
                        break;
                    case 2:
                        averageDamage1 = 35;    //Spell
                        break;
                    case 4:
                        averageDamage1 = 15;    //Punch
                        break;
                    case 6:
                        averageDamage1 = 25;    //Bite
                        break;
                    //voor latere mij, voeg meer switch-statements toe naarmate je meer aanvallen toevoegd.
                }
            }
        }
        //voor secondary attacks
        for (int i = 1; i <= allAttacks.length; i += 2){
            if (attack2.equals(allAttacks[i])){
                switch(i){
                    case 1:
                        averageDamage2 = 20;    //moet worden aangepast
                        break;
                    case 3:
                        aantalLevens += 20;     //moet worden aangepast
                        break;
                    case 5:
                        averageDamage2 = 15;    //moet worden aangepast
                        break;
                    case 7:
                        averageDamage2 = 25;    //moet worden aangepast
                        break;
                    //voor latere mij, voeg meer switch-statements toe naarmate je meer aanvallen toevoegd.
                }
            }
        }
    }
    public void valAan(){
        schadeDezeRonde = bepaalSchade();
        
        isDood();
        if (schadeDezeRonde == -999){
            System.out.println(naam + " the " + kindOfEnemy + " did not use a physical attack.");
            //hier moet een methode komen dat print wat de vijand effectief heeft gedaan met zijn aanval als deze niet fysiek was.
            return;
        }
        if (!isDood && !speler.isDead()){
            speler.setAmountOfLives(speler.getAmountOfLives() - schadeDezeRonde);
            if(speler.getAmountOfLives() < 0){
                speler.setAmountOfLives(0);           
            }
        }
        printDamageThisRound();
        // Hier valt de speler aan en wordt de vijand schade toegebracht
    }
    private int chooseAttack(){
        return rnd.nextInt(2);
    }
    private int bepaalSchade(){
        int chosenAverageDamage = 0;
        int generatedValue = chooseAttack();
        
        if (averageDamage1 != 0){
            if (generatedValue == 0){
                chosenAverageDamage = averageDamage1;
            }
        }
        if (averageDamage2 != 0){
            if (generatedValue == 1){
                chosenAverageDamage = averageDamage2;
            }
        }
        if (chosenAverageDamage == 0){
            return -999;
        }
        
        int maxDmg = chosenAverageDamage + 5;
        int minDmg = chosenAverageDamage - 5;
        schadeDezeRonde = 0;
        int getal = rnd.nextInt(11);
        
        //crit damage
        int getal2 = rnd.nextInt(100) + 1;
        double damageMultiplier = 1;
        
        if (critChance >= getal2){
            damageMultiplier = 1.5;
            System.out.println("Crit!");
        }
        
        if (getal < 5){
            schadeDezeRonde = (int) Math.round((chosenAverageDamage - (getal + 1)) * damageMultiplier);
        }
        else if (getal > 5){
            schadeDezeRonde = (int) Math.round((chosenAverageDamage + getal - 5) * damageMultiplier);
        }
        else if (getal == 5){
            schadeDezeRonde = (int) Math.round(chosenAverageDamage * damageMultiplier);
        }
        
        return schadeDezeRonde;
    }
    public void setAantalLevens(int aantalLevens){
        this.aantalLevens = aantalLevens;
    }
    public int getAantalLevens(){
        return aantalLevens;
    }
    public Speler huidigeSpeler(){
        return huidigeSpeler;
    }
    public String getName(){
        return naam;
    }
    public String getKindOfEnemy(){
        return kindOfEnemy;
    }
    public String determineEnemie(){
        int chooseEnemy = rnd.nextInt(kindsOfEnemies.length);
        
        kindOfEnemy = kindsOfEnemies[chooseEnemy];
        
        return kindOfEnemy;
    }
    public int determineLives(){
        //"Wolf","Wizard","Goblin","Zombie"
        if (kindOfEnemy.equals("Wolf")){
            aantalLevens = 80;
        }
        else if(kindOfEnemy.equals("Wizard")){
            aantalLevens = 120;
        }
        else if(kindOfEnemy.equals("Goblin")){
            aantalLevens = 60;
        }
        else if(kindOfEnemy.equals("Zombie")){
            aantalLevens = 100;
        }
        return aantalLevens;
    }
    public String determineName(){
        // "James", "Robert", "John", "Michael", "David", "William" | "Mary", "Patricia", "Jennifer", "Linda", "Lisa"
        // bro this method took me so long to write and it finally works
        List<String> possibleNamesArrayList = new ArrayList<>(Arrays.asList(possibleNames));
        
        int choosingNameIndex = rnd.nextInt(possibleNamesArrayList.size());
        naam = possibleNames[choosingNameIndex];
        
        possibleNamesArrayList.subList(choosingNameIndex, choosingNameIndex + 1).clear();
        possibleNames = possibleNamesArrayList.toArray(new String[possibleNamesArrayList.size()]);
        
        return naam;
    }
    public void printDamageThisRound(){
        int gekozenAanval = chooseAttack();
        if (gekozenAanval == 0){
            System.out.println(naam + " did do " + schadeDezeRonde + " damage to " + speler.getName() + " with his first attack " + attack1 + ". ");
        }
        if (gekozenAanval == 1){
            System.out.println(naam + " did do " + schadeDezeRonde + " damage to " + speler.getName() + " with his second attack " + attack2 + ". ");
        }
        else{
            //hier moet een methode komen voor het printen wat een vijand doet als hij een aanval gebruikt die geen fysieke schade toebrengt.
        }
    }
}