public class Aanval
{
    private String naam;
    private int waarde;
    
    private String[] categoriën;
    private Effect effect; //de effecten die horen bij een aanval
    
    private static String[] allBaseAttacks = {"Overhead Smash", "Crushing Blow", "Slash", "Spin Attack", "Stab", "Precision Throw", "Uppercut", "Quick Punches"};
    private static String[] allWeaponAttacks = {"Overhead Smash", "Crushing Blow", "Slash", "Spin Attack", "Stab", "Precision Throw", "Uppercut", "Quick Punches"};
    private static String[] allCategories = {"Melee", "Ranged"};
    
    private static Aanval[] allAttacks = new Aanval[]{
    new Aanval("Uppercut", 18, new Effect("Damage One", "Normal", "Do an uppercut."), new String[] {"Melee"}),
    new Aanval("Quick Punches", 10, new Effect("Damage One", "Multi Hit", "Hit the enemy twice rapidly."), new String[] {"Melee"}),
    new Aanval("Overhead Smash", 25, new Effect("Damage One", "Normal", "Smash the enemy real hard."), new String[] {"Melee"}),
    new Aanval("Crushing Blow", 20, new Effect("Damage One", "Final Hit", "TBA. Does 2x damage if enemy under 50 health."), new String[] {"Melee"}),
    new Aanval("Slash", 30, new Effect("Damage One", "Normal", "Slash through the enemy."), new String[] {"Melee"}),
    new Aanval("Spin Attack", 15, new Effect("Damage All", "Normal", "Does a spin attack with the weapon that let's it do damage to all enemies."), new String[] {"Melee"}),
    new Aanval("Stab", 15, new Effect("Damage One", "Damage Over Time", "Lets the attacked enemy bleed for 2 turns taking 5 damage each time."), new String[] {"Melee"}),
    new Aanval("Precision Throw", 20, new Effect("Damage One", "Normal", "Throw your knife to the chosen enemy."), new String[] {"Melee"}),
    new Aanval("Full Metal Jacket", 35, new Effect("Damage One", "Normal", "Shoot a devestating bullet to the enemy."), new String[] {"Ranged"}),
    new Aanval("Final Blow", 20, new Effect("Damage One", "Final Hit", "Shoot a deadly bullet to the enemy. Does 2x damage if enemy under 50 health."), new String[] {"Ranged"})
    };
    
    public Aanval(String naam, int waarde, Effect effect, String[] categoriën){
        this.naam = naam;
        this.waarde = waarde;
        this.effect = effect;
        this.categoriën = categoriën;
    }
    public static void determineBaseAttacks(Wapen wapen){
        int i = 0;
        
        for (String weaponName: wapen.getWeaponNames()){
            if (wapen.getWeaponName().equals(weaponName)){
                wapen.setBaseAanvallen(i);
                return;
            }
            i = i + 2;
        }
        System.out.println("You have the maximal amount of attacks.");
    }
    public static String[] getAllBaseAttacks(){
        return allBaseAttacks;
    }
    public static Aanval[] getAllAttacks(){
        return allAttacks;
    }
    public String getName(){
        return naam;
    }
    public Effect getEffect(){
        return effect;
    }
    public String[] getCategoriën(){
        return categoriën;
    }
    public int getWaarde(){
        return waarde;
    }
}
