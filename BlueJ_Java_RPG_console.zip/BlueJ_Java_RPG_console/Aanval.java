public class Aanval
{
    private String naam;
    private int waarde;
    
    private String[] categoriën;
    private Effect effect; //de effecten die horen bij een aanval
    
    private static String[] allBaseAttacks = {"Overhead Smash", "Crushing Blow", "Slash", "Spin Attack", "Stab", "Precision Throw", "Uppercut", "Quick Punches"};
    private static String[] allWeaponAttacks = {"Overhead Smash", "Crushing Blow", "Slash", "Spin Attack", "Stab", "Precision Throw", "Uppercut", "Quick Punches"};
    private static String[] allCategories = {"Melee", "Ranged", "Other"};
    
    private static Aanval[] allPlayerAttacks = new Aanval[]{
    new Aanval("Uppercut", 18, new Effect("Damage One", "Normal", "Do an uppercut."), new String[] {"Melee"}),
    new Aanval("Quick Punches", 10, new Effect("Damage One", "Multi Hit", "Hit the enemy twice rapidly."), new String[] {"Melee"}),
    new Aanval("Overhead Smash", 25, new Effect("Damage One", "Normal", "Smash the enemy real hard."), new String[] {"Melee"}),
    new Aanval("Crushing Blow", 20, new Effect("Damage One", "Final Hit", "TBA. Does 2x damage if enemy under 50 health."), new String[] {"Melee"}),
    new Aanval("Slash", 30, new Effect("Damage One", "Normal", "Slash through the enemy."), new String[] {"Melee"}),
    new Aanval("Spin Attack", 15, new Effect("Damage All", "Normal", "Does a spin attack with the weapon that let's it do damage to all enemies."), new String[] {"Melee"}),
    new Aanval("Stab", 15, new Effect("Damage One", "Damage Over Time", "Lets the attacked enemy bleed for 2 turns taking 5 damage each time."), new String[] {"Melee"}),
    new Aanval("Precision Throw", 20, new Effect("Damage One", "Normal", "Throw your knife to the chosen enemy."), new String[] {"Melee"}),
    new Aanval("Full Metal Jacket", 35, new Effect("Damage One", "Normal", "Shoot a devestating bullet to the enemy."), new String[] {"Ranged"}),
    new Aanval("Final Blow", 20, new Effect("Damage One", "Final Hit", "Shoot a deadly bullet to the enemy. Does 2x damage if enemy under 50 health."), new String[] {"Ranged"})
    };
    
    // static String[] allAttacks = {"Claws", "Roar", "Spell", "Healing Drink", "Punch", "Gold Steal", "Bite", "Grab"};
    private static Aanval[] allEnemyAttacks = new Aanval[]{
    new Aanval("Claws", 18, new Effect("Damage One", "Damage Over Time", "Attacks player with its sharp claws letting the player bleed."), new String[] {"Melee"}),
    new Aanval("Roar", 0, new Effect("Debuff One", "Normal", "Makes the player scared letting them do less damage."), new String[] {"Other"}),
    new Aanval("Spell", 30, new Effect("Damage One", "Normal", "SHAZAM! Attacks the player with a powerful spell"), new String[] {"Ranged"}),
    new Aanval("Healing Drink", 25, new Effect("Heal Self", "Normal", "Heals the user."), new String[] {"Other"}),
    new Aanval("Punch", 15, new Effect("Damage One", "Normal", "Punch the player."), new String[] {"Melee"}),
    new Aanval("Gold Steal", 5, new Effect("Damage One", "Remove Gold", "Steals some coins of the players."), new String[] {"Melee"}),
    new Aanval("Bite", 15, new Effect("Damage One", "Damage Over Time", "Om nom nom."), new String[] {"Melee"}),
    new Aanval("Grab", 20, new Effect("Damage One", "Normal", "Grabs the player."), new String[] {"Melee"})
    };
    
    
    public Aanval(String naam, int waarde, Effect effect, String[] categoriën){
        this.naam = naam;
        this.waarde = waarde;
        this.effect = effect;
        this.categoriën = categoriën;
    }
    public static void determineBaseAttacks(Wapen wapen){
        int i = 0;
        
        for (String weaponName: wapen.getWeaponNames()){
            if (wapen.getWeaponName().equals(weaponName)){
                wapen.setBaseAanvallen(i);
                return;
            }
            i = i + 2;
        }
        System.out.println("You have the maximal amount of attacks.");
    }
    public static String[] getAllBaseAttacks(){
        return allBaseAttacks;
    }
    public static Aanval[] getAllPlayerAttacks(){
        return allPlayerAttacks;
    }
    public static Aanval[] getAllEnemyAttacks(){
        return allEnemyAttacks;
    }
    public String getName(){
        return naam;
    }
    public Effect getEffect(){
        return effect;
    }
    public String[] getCategoriën(){
        return categoriën;
    }
    public int getWaarde(){
        return waarde;
    }
}
