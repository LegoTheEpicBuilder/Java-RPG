import java.util.Arrays;

public class Effect{
    private String description;
    private String effectSoort;
    private String specialEffect;
    
    private static String[] effectSoorten = {"Damage One", "Damage All", "Heal Self", "Heal Other", "Heal All", "Buff"};
    private static String[] specialEffects = {"Normal", "Damage Over Time", "Final Hit", "Multi Hit"}; //bru-bru-bruh
    
    public Effect(String effectSoort, String specialEffect, String description){
        this.effectSoort = effectSoort;
        this.specialEffect = specialEffect;
        this.description = description;
    }
    public static String[] getEffectSoorten(){
        return effectSoorten;
    }
    public String getEffectSoort(){
        return effectSoort;
    }
    public String getSpecialEffect(){
        return specialEffect;
    }
    public String getDescription(){
        return description;
    }
}