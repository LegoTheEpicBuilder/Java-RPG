public class Enchanter{
    /*
    deze klasse is voor: 
    - het zetten van damageOverTime effecten op een aanval. (random gegenereerd)
    - het upgraden van damageOverTime effecten op een aanval.
    - ???
    */
}