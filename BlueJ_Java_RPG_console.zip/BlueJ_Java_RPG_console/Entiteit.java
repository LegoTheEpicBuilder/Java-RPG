import java.util.*;

public class Entiteit{
    protected String name = "Unknown";
    protected int maxAmountOfLives;
    protected int amountOfLives;
    
    protected boolean isDead = false;
    protected boolean isFirstDeath = true;
    protected Wapen weapon;
    
    protected ArrayList <Effect> damageOverTimeEffects = new ArrayList <Effect>();
    
    public Entiteit(String name){   //voor Speler
        this.name = name;
        amountOfLives = 100;
        maxAmountOfLives = 100;
    }
    public Entiteit(int amountOfLives){    //voor Vijand
        this.amountOfLives = amountOfLives;
        maxAmountOfLives = amountOfLives;
    }
    
    public boolean isDead(){
        if (amountOfLives <= 0){
            isDead = true;
        }
        return isDead;
    }
    public void doDamageOverTime(){
        try{
            for (Effect effect: damageOverTimeEffects){
                if (effect.getValue2() > 0){
                    amountOfLives -= effect.getValue1();
                    effect.setValue2(Math.round(effect.getValue2() - 1));
                    
                    if (amountOfLives < 0){
                        amountOfLives = 0;
                    }
                    
                    printDamageOverTime();
                }
                if (effect.getValue2() == 0){
                    damageOverTimeEffects.remove(effect);
                }
            }
        }
        catch (ConcurrentModificationException e){
            //try en catch is niet de beste oplossing maar het werkt. Je mag niet een effect verwijderen wanneer deze nog in een loop zit en deze verder nog wordt gebruikt.
        }
    }
    public void printDamageOverTime(){
        for (Effect effect : damageOverTimeEffects){
            if (amountOfLives != 0){
                System.out.println(name + " got damaged by " + effect.getName() + " for " + effect.getValue1() + " damage. (" + amountOfLives + "hp)");
            }
            else{
                System.out.println(name + " got damaged by " + effect.getName() + " for " + effect.getValue1() + " damage. (dead)");
            }
        }
    }
    
    //getters and setters
    public void setAmountOfLives(int amountOfLives){
        if (amountOfLives <= maxAmountOfLives){
            this.amountOfLives = amountOfLives;
        }
        else{
            this.amountOfLives = maxAmountOfLives;
        }
    }
    public int getAmountOfLives(){
        return amountOfLives;
    }
    public String getName(){
        return name;
    }
    public boolean getIsFirstDeath(){
        return isFirstDeath;
    }
    public void setIsFirstDeath(boolean isFirstDeath){
        this.isFirstDeath = isFirstDeath;
    }
    public void printDeath(){
        if (isFirstDeath){
            System.out.println(this.getName() + " died.");
            isFirstDeath = false;
        }
    }
    public void setDamageOverTime(Effect effect){
        //voegt alleen maar een nieuw effect toe als er nog geen effect bestaat van dezelfde naam. (vb. bleed, burn,...)
        //als het effect al bestaat verlengt het de duur en kiest het de hoogste schade van beide effecten.
        for (Effect effectInList: this.getDamageOverTimeEffects()){
            if (effectInList.getName().equals(effect.getName())){
                effectInList.setValue2(effectInList.getValue2() + effect.getValue2());
                
                if (effect.getValue1() > effectInList.getValue1()){
                    effectInList.setValue1(effect.getValue1());
                }
                return;
            }
        }
        damageOverTimeEffects.add(effect);
    }
    public ArrayList <Effect> getDamageOverTimeEffects(){
        return damageOverTimeEffects;
    }
    public int getMaxAmountOfLives(){
        return maxAmountOfLives;
    }
    public void setMaxAmountOfLives(int maxAmountOfLives){
        this.maxAmountOfLives = maxAmountOfLives;
    }
    public void setIsDead(boolean isDead){
        this.isDead = isDead;
    }
    public boolean getIsDead(){
        return isDead;
    }
    public Wapen getWeapon(){
        return weapon;
    }
    public void setWeapon(Wapen weapon){
        this.weapon = weapon;
    }
}