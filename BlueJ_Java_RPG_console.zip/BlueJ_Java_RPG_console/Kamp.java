public class Kamp{
    
}