import java.util.Scanner;
import java.util.*;
public class Kamp{
    
    static Scanner sc = new Scanner(System.in);
    
    public static void makeChoice(){
        String choice = "";
        int optionIndex = 1;
        boolean isNotValidInput = true;
        String[] options = {"Equip weapon", "Unequip weapon", "Heal up", "Check backpack", "Check info", "Go back"};
        Spel.setPlayerLocation("Camp");
        
        printGreeting();
        //player makes choice between options
        //checking for valid input
        while (isNotValidInput){    
            
            System.out.println("__________" + "\n" + "What do you wanna do now? " + "\n" + "Possible choices: " + "\n");
            //prints the options
            optionIndex = 1;
            for (String option: options){
                System.out.println(optionIndex + ": " + option);
                optionIndex++;
            }
            choice = sc.nextLine();
            
            optionIndex = 1;
            for (String option: options){
                if (choice.equalsIgnoreCase(option) || choice.equals(Integer.toString(optionIndex))){
                    isNotValidInput = false;
                    break;
                }
                else{
                    isNotValidInput = true;
                }
                if (optionIndex == options.length){
                    System.out.println("Invalid input. Please try again.");
                }
                optionIndex++;
            }
        }
        if (choice.equalsIgnoreCase(options[0]) || choice.equals("1")){
            equipWeapon();
            makeChoice();
        }
        else if(choice.equalsIgnoreCase(options[1]) || choice.equals("2")){
            unequipWeapon();
            makeChoice();
        }
        else if(choice.equalsIgnoreCase(options[2]) || choice.equals("3")){
            healing();
            makeChoice();
        }
        else if(choice.equalsIgnoreCase(options[3]) || choice.equals("4")){
            Rugzak.printRugzak();
            makeChoice();
        }
        else if(choice.equalsIgnoreCase(options[4]) || choice.equals("5")){
            chooseInfoOption();
            sc.nextLine();
            makeChoice();
        }
        else if(choice.equalsIgnoreCase(options[5]) || choice.equals("6")){
            printLeaving();
            Spel.makeChoice();
        }
        else{
            System.out.println("Invalid input.");
            makeChoice();
        }
    }
    public static void equipWeapon(){
        if (Rugzak.getWeapons().size() == 0){
            System.out.println("Canceled request. No weapons found in your backpack.");
            return;
        }
        
        Speler chosenPlayer = null;
        Wapen chosenWeapon = null;
        Wapen oldWeapon = null;
        int index = 0;
        
        
        //het kiezen van de speler
        Spel.printPlayerWeapons();
        System.out.println("Which player do you wanna let equip something? (number)");
        String input = sc.nextLine();
        
        //dit systeem fixt het meeste, maar zal nog steeds een error geven wanneer er iets anders dan een integer wordt ingegeven
        //werkt met String en index
        
        for (Speler speler: Spel.getSpelers()){
            if (!(Integer.parseInt(input) > Spel.getSpelers().length) && Spel.getSpelers()[Integer.parseInt(input) - 1] == Spel.getSpelers()[index]){
                chosenPlayer = Spel.getSpelers()[index];
                break;
            }
            index++;
        }
        if (index == Spel.getSpelers().length){
            System.out.println("Invalid input. Equipping weapon failed.");
            return;
        }
        index = 0;
        
        //het kiezen van het wapen
        Rugzak.printWeapons();
        System.out.println("What weapon does " + chosenPlayer.getName() + " need to equip? (number)");
        int input2 = sc.nextInt();
        
        //werkt alleen met index
        
        for (Wapen wapen: Rugzak.getWeapons()){
            if (Rugzak.getWeapons().get(input2 - 1) == Rugzak.getWeapons().get(index) && Rugzak.getWeapons().get(input2 - 1) != null){
                chosenWeapon = Rugzak.getWeapons().get(index);
                break;
            }
            index++;
            if (Rugzak.getWeapons().get(input2 - 1) == null){
                oldWeapon = chosenPlayer.getWeapon();
                
                if (!(chosenPlayer.getWeapon().getName().contains("Fists"))){
                    Rugzak.setWeaponItem(input2, oldWeapon);
                    chosenPlayer.setWeapon(Wapen.getAllWeapons()[0]);
                    System.out.println(chosenPlayer.getName() + " unequipped his/her weapon.");
                }
                else{
                    System.out.println("What did you even try to do?");
                }
                return;
            }
            if (index == Rugzak.getWeapons().size()){
                System.out.println("Invalid input. Equipping weapon failed.");
                return;
            }
        }
        
        //het geven van het wapen aan de speler als het gekozen wapen niet vuisten is
        
        oldWeapon = chosenPlayer.getWeapon();
        chosenPlayer.setWeapon(chosenWeapon);
        System.out.println("Succesfully equipped " + chosenWeapon.getName() + ".");
        sc.nextLine();
        
        //ik heb hier code verwijderd
        
        //zet het oude wapen als het niet handen is op dezelfde plek van waar de speler zijn wapen koos 
        if (oldWeapon.getName().contains("Fists")){
            Rugzak.setWeaponItem(index, null);
        }
        else{
            Rugzak.setWeaponItem(index, oldWeapon);
            System.out.println("The old weapon from " + chosenPlayer.getName() + " has been added to your inventory.");
        }
        System.out.println("Done!");
    }
    public static void unequipWeapon(){
        Speler chosenPlayer = null;
        Wapen unequippedWeapon = null;
        int index = 0;
        
        //het kiezen van de speler
        Spel.printPlayerWeapons();
        System.out.println("Which player do you wanna let unequip his weapon? (number)");
        String input = sc.nextLine();
        
        //werkt alleen met index
        while (chosenPlayer == null){
            for (Speler speler: Spel.getSpelers()){
                if (!(Integer.parseInt(input) > Spel.getSpelers().length) && Spel.getSpelers()[Integer.parseInt(input) - 1] == Spel.getSpelers()[index]){ //0 & -1
                    chosenPlayer = Spel.getSpelers()[index];
                    unequippedWeapon = speler.getWeapon();
                    break;
                }
                index++;
            }
            if (index == Spel.getSpelers().length){
                System.out.println("Invalid input. Please try again.");
                input = sc.nextLine();
                index = 0;
            }
        }
        index = 0;
        
        if (!(unequippedWeapon.getName().contains("Fists"))){
            for (Wapen wapen: Rugzak.getWeapons()){
                if (wapen == null){
                    Rugzak.setWeaponItem(index, unequippedWeapon);
                    break;
                }
                index++;
                if (index == Rugzak.getWeapons().size()){
                    Rugzak.replaceWeapon(unequippedWeapon);
                }
            }
            chosenPlayer.setWeapon(Wapen.getAllWeapons()[0]);
            System.out.println("Succesfully unequipped " + unequippedWeapon.getName());
        }
        else{
            System.out.println(chosenPlayer.getName() + " does not have any weapon equipped!");
        }
    }
    public static void healing(){
        String[] options = {"Heal player 50% of max health", "Fully heal player", "Heal full team", "Go back"}; //'go back' has to be last one
        int[] prices = {30, 50, 100, 0}; //0 always has to be last value
        int choice;
        
        boolean success = false;
        
        while (success == false){
            try{
                System.out.println("Possible options: ");
                for (int i = 0; i < options.length; i++){
                    if (i == options.length - 1){
                        System.out.println((i + 1) + ": " + options[options.length - 1]);
                    }
                    else{
                        System.out.println((i + 1) + ": " + options[i] + " (" +  prices[i] + " coins)");
                    }
                }
                Rugzak.printCoins();
                
                choice = sc.nextInt();
                
                if (Rugzak.getCoins() < prices[choice - 1]){
                    System.out.println("You don't have enough money for this!");
                }
                else{
                    if (choice == 1 || choice == 2){
                        System.out.println("__________" + "\n" + "Choose a player to heal: ");
                        Spel.printPlayerStats();
                        
                        int choice2 = sc.nextInt();
                        Speler chosenPlayer = Spel.getSpelers()[choice2 - 1];
                    
                        if (!(chosenPlayer.isDead()) && chosenPlayer.getAmountOfLives() != chosenPlayer.getMaxAmountOfLives()){
                            Rugzak.setCoins(Rugzak.getCoins() - prices[choice - 1]);
                            if (choice == 1){
                                chosenPlayer.setAmountOfLives(chosenPlayer.getAmountOfLives() + chosenPlayer.getMaxAmountOfLives() / 2);
                            }
                            else if (choice == 2){
                                chosenPlayer.setAmountOfLives(chosenPlayer.getMaxAmountOfLives());
                            }
                            
                            System.out.println("Succesfully healed " + chosenPlayer.getName() + " (" + chosenPlayer.getAmountOfLives() + " hp).");
                            success = true;
                            }
                            else if (chosenPlayer.isDead()){
                            System.out.println("You cannot heal dead people!");
                            }
                            else if (chosenPlayer.getAmountOfLives() == chosenPlayer.getMaxAmountOfLives()){
                            System.out.println(chosenPlayer.getName() + " is already max health!");
                        }
                    }
                    else if (choice == 3){
                        for (Speler speler: Spel.getSpelers()){
                            if (!speler.isDead()){
                                speler.setAmountOfLives(speler.getMaxAmountOfLives());
                            }
                        }
                        System.out.println("Succesfully healed everyone.");
                        success = true;
                    }
                    else if (choice == 4){
                        System.out.println("Going back...");
                        success = true;
                        sc.nextLine();
                    }
                    else{
                        System.out.println("Invalid input. Please try again.");
                    }
                }
            }
            catch(InputMismatchException e){
                System.out.println("Invalid input. Please try again. No strings allowed.");
                sc.nextLine();
            }
            catch(Exception e){
                System.out.println("Invalid input. Please try again. exception found: " + e);
            }
        }
    }
    public static void chooseInfoOption(){
        int choice;
        String[] options = {"Weapon list", "All obtainable attacks list", "All enemy attacks list", "Nothing"};
        
        System.out.println("__________" + "\n" + "What do you wanna check out?" + "\n" + "Possible choices:" + "\n");
        
        for (int i = 0; i < options.length; i++){
            System.out.println(i + 1 + ": " + options[i]);
        }
        
        try{
            choice = sc.nextInt() - 1;
            
            switch(choice){
                case 0:
                    Wapen.printAllWeapons();
                    break;
                case 1:
                    Aanval.printAllPlayerAttacksInfo();
                    break;
                case 2:
                    Aanval.printAllEnemyAttacksInfo();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid input.");
            }
        }
        catch(Exception e){
            System.out.println("Invalid input.");
        }
    }
    public static void printGreeting(){
        System.out.println("You and your team safely get back to camp.");
    }
    public static void printLeaving(){
        System.out.println("You and your team leave the camp.");
    }
}