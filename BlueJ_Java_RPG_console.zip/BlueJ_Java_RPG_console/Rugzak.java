import java.util.Random;
import java.util.Scanner;
public class Rugzak
{
    private static int size = 10;
    private static int coinPouchSize = 250;
    private static int coins = 0;
    
    private static String[] rugzak = new String[size];
    
    private static Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public static void dropLoot(){
        String chosenLootDrop;
        boolean isToegevoegd = false;
        
        for (Vijand vijand: Spel.getVijanden()){
            chosenLootDrop = Wapen.getWeaponNames()[rnd.nextInt(Wapen.getWeaponNames().length)];

            int j = 0;
            int i = 0;
            
            coins += vijand.calculateCoinDrop(); //checkt de hoeveelheid munten dat een vijand laat vallen na zijn dood.
            System.out.println(vijand.getName() + " dropped " + vijand.calculateCoinDrop() + " coins.");
            
            if (i < rugzak.length){
                while (i < rugzak.length){
                    if (rugzak[i] == null){
                        rugzak[i] = chosenLootDrop;
                        System.out.println("The " + chosenLootDrop + " that " + vijand.getName() + " dropped has been succesfully added to your inventory.");
                        i++;
                        break;
                    }
                    else{
                        i++;
                    }
                }
            }
            else{
                //replacing item if backpack is full
                System.out.println("Your backpack is full. Do you want to replace an item and store " + chosenLootDrop + "?" + "\n" + "Yes / No");
                String askIfReplaceItem = sc.nextLine();
                
                if (askIfReplaceItem.equalsIgnoreCase("Yes")){
                    System.out.println("\n" + "__________" + "\n" + "Your backpack: ");
                    
                    for (String wapenRugzak: rugzak){
                        System.out.println((j + 1) + ": " + wapenRugzak);
                        j++;
                    }
                    System.out.println("__________");
                    System.out.println("What item do you want to replace? ");
                    
                    int ReplaceItemIndex = sc.nextInt() - 1;
                    
                    if (ReplaceItemIndex >= rugzak.length){
                        System.out.println("Invalid index given. Try again.");
                        ReplaceItemIndex = sc.nextInt() - 1;
                    }
                    else{
                        String replacedItem = rugzak[ReplaceItemIndex];
                        rugzak[ReplaceItemIndex] = chosenLootDrop;
                        System.out.println("The " + replacedItem + " has been succesfully replaced by " + chosenLootDrop + ".");
                    }
                }
            }
        }
    }
    public static String[] getRugzak(){
        return rugzak;
    }
    public static String setRugzakItem(int index, String item){
        return rugzak[index] = item;
    }
    public void setSizeRugzak(int size){
        this.size = size;
        
        String[] newRugzak = new String[size];
        for (int i = 0; i < rugzak.length; i++) {
            newRugzak[i] = rugzak[i];
        }
        
        rugzak = newRugzak;
    }
    public void printRugzak(){
        System.out.println("\n" + "__________" + "\n" + "Your backpack: ");
        int j = 0;            
        for (String wapenRugzak: rugzak){
            System.out.println((j + 1) + ": " + wapenRugzak);
            j++;
        }
    }
    public void printCoins(){
        System.out.println("You have " + coins + " coins.");
    }
    public static int getCoinPouchSize(){
        return coinPouchSize;
    }
    public static int getCoins(){
        return coins;
    }
    public static void setCoins(int coin){
        if (coins + coin <= coinPouchSize){
            coins = coin;
        }
        else{
            coins = coinPouchSize;
        }
    }
}
