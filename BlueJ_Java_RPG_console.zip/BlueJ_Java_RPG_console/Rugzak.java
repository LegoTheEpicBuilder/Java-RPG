import java.util.Random;
import java.util.Scanner;
import java.util.*;
public class Rugzak
{
    private static int coinPouchSize = 250;
    private static int coins = 0;
    
    private static int maxWeight = 25;
    
    private static ArrayList <Voorwerp> rugzak = new ArrayList <Voorwerp>();
    private static ArrayList <Wapen> weapons = new ArrayList <Wapen>();
    private static ArrayList <Aanval> attacks = new ArrayList <Aanval>();
    
    private static Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public static void addItems(ArrayList<Voorwerp> items){
        rugzak.clear();
        rugzak.addAll(weapons);
        rugzak.addAll(attacks);
        
        for (Voorwerp voorwerp : items){
            if (voorwerp instanceof Wapen){
                weapons.add((Wapen) voorwerp);
            }
            else if (voorwerp instanceof Aanval){
                attacks.add((Aanval) voorwerp);
            }
        }
    }
    public static ArrayList<Voorwerp> getRugzak(){
        refillRugzak();
        return rugzak;
    }
    public static void refillRugzak(){
        rugzak.clear();
        rugzak.addAll(weapons);
        rugzak.addAll(attacks);
    }
    public static double getTotalWeight(){
        double totalWeight = 0;
        
        rugzak.clear();
        rugzak.addAll(weapons);
        rugzak.addAll(attacks);
        
        for (Voorwerp voorwerp: rugzak){
            totalWeight = totalWeight + voorwerp.getWeight();
        }
        return totalWeight;
    }
    public static double getMaxWeight(){
        return maxWeight;
    }
    public static void dropLoot(){
        Voorwerp chosenLootDrop = null;
        boolean isToegevoegd = false;
        
        String printBagFull = "";
        
        for (Vijand vijand: Spel.getVijanden()){
            int i = 0;
            int chosenCoinDrop = vijand.calculateCoinDrop(); //checkt de hoeveelheid munten dat een vijand laat vallen na zijn dood.
            
            if (coinPouchSize > coins + chosenCoinDrop){
                coins += chosenCoinDrop;
            }
            else{
                coins = coinPouchSize;
                printBagFull = " (full!)";
            }
            
            System.out.println(vijand.getName() + " dropped " + chosenCoinDrop + " coins.");
            
            //kiezen van soort voorwerp om te droppen
            int chosenVoorwerpKind = rnd.nextInt(2);
            double totalWeight = 0;
            boolean isAdded = false;
            
            //rugzak vullen met alle voorwerpen
            rugzak.clear();
            rugzak.addAll(weapons);
            rugzak.addAll(attacks);
            
            //checken als voorwerpen niet maximaal gewicht overschrijden
            for (Voorwerp voorwerp: rugzak){
                totalWeight = totalWeight + voorwerp.getWeight();
            }
            
            if (chosenVoorwerpKind == 0){
                 chosenLootDrop = Wapen.getRandomWeaponNoFists();
                 
                 if (totalWeight + chosenLootDrop.getWeight() < maxWeight){
                     weapons.add((Wapen) chosenLootDrop);
                     isAdded = true;
                     System.out.println("The " + chosenLootDrop.getRarity() + " weapon " + chosenLootDrop.getName() + " that " + vijand.getName() + " dropped has been succesfully added to your inventory.");
                 }
                 
                 //chosenArrayList.addAll(weapons);
            }
            else if (chosenVoorwerpKind == 1){
                chosenLootDrop = Aanval.getRandomAttack();
                
                if (totalWeight + chosenLootDrop.getWeight() < maxWeight){
                     attacks.add((Aanval) chosenLootDrop);
                     isAdded = true;
                     System.out.println("The " + chosenLootDrop.getRarity() + " attack " + chosenLootDrop.getName() + " that " + vijand.getName() + " dropped has been succesfully added to your inventory.");
                }
                
                //chosenArrayList.addAll(attacks);
            }
            //
            
            //checking for full backpack
            if (totalWeight + chosenLootDrop.getWeight() > maxWeight && isAdded == false){
                System.out.println(vijand.getName() + " dropped a " + chosenLootDrop.getRarity() + " " + chosenLootDrop.getName());
                
                //replacing weapon if backpack is full
                System.out.println("Your backpack is full. Do you want to replace an item and store " + chosenLootDrop.getName() + "?" + "\n" + "Yes / No");
                String askIfReplaceItem = sc.nextLine();
                int j;
                
                boolean isFull = true;
                ArrayList <Integer> replacedItems = new ArrayList <Integer>();
                int replacedItemsWeight = 0;
                String oldItem = "";
                
                if (askIfReplaceItem.equalsIgnoreCase("Yes")){
                    while (isFull){ //loops as long as there isn't enough space in backpack
                        j = 0;
                        System.out.println("\n" + "__________" + "\n" + "Your backpack: ");
                        System.out.println("Your weapons: ");
                        for (Wapen wapenRugzak: weapons){
                            System.out.println((j + 1) + ": " + wapenRugzak.getName() + " (weight = " + wapenRugzak.getWeight() + ")");
                            j++;
                        }
                        System.out.println("Your attacks: ");
                        for (Aanval aanvalRugzak: attacks){
                            System.out.println((j + 1) + ": " + aanvalRugzak.getName() + " (weight = " + aanvalRugzak.getWeight() + ")");
                            j++;
                        }
                        System.out.println("__________");
                        System.out.println("What item do you want to replace? ");
                        
                        int replaceItemIndex = sc.nextInt() - 1;
                        
                        //adding index to arraylist
                        if (replaceItemIndex < weapons.size() + attacks.size()){
                            replacedItems.add(replaceItemIndex);
                            
                            //testing
                            System.out.println(replacedItems);
                        }
                        else{
                            System.out.println("Invalid index given. Canceled replacing item.");
                            return;
                        }
                        
                        //calculating weight of replaced items
                        for (Integer index: replacedItems){
                            if (index < weapons.size()){
                                replacedItemsWeight += weapons.get(index).getWeight();
                            }
                            else{
                                replacedItemsWeight += attacks.get(index - weapons.size()).getWeight();
                            }
                        }
                        
                        //checking if weight still to much
                        if (totalWeight - replacedItemsWeight + chosenLootDrop.getWeight() > maxWeight){
                            System.out.println("Inventory is still full. Replace another item.");
                        }
                        else{
                            //if there are enough items chosen to replace the lootdrop with, the replaced items get deleted and lootdrop gets added.
                            isFull = false;
                            
                            //removing replaced items
                            for (Integer index: replacedItems){
                                if (index < weapons.size()){
                                    oldItem = weapons.get(index.intValue()).getName();
                                    weapons.remove(index.intValue());
                                }
                                else{   //weapons: 8, attacks, 5, gekozen index: 3
                                    oldItem = attacks.get(index.intValue() - weapons.size()).getName();
                                    attacks.remove(index.intValue() - weapons.size());
                                }
                            }
                            
                            //adding lootdrop
                            if (chosenLootDrop instanceof Wapen){
                                weapons.add((Wapen) chosenLootDrop);
                            }
                            else if (chosenLootDrop instanceof Aanval){
                                attacks.add((Aanval) chosenLootDrop);
                            }
                        }
                    }
                    
                    // printing removed items
                    if (replacedItems.size() == 1){
                        System.out.println("The " + oldItem + " has been succesfully replaced by " + chosenLootDrop.getName() + ".");
                    }
                    else{
                        System.out.println("The items have been succesfully replaced by " + chosenLootDrop.getName() + ".");
                    }
                    sc.nextLine();
                }
            }
        }
        
        //printing values no matter what
        System.out.println("Your coins: " + coins + " / " + coinPouchSize + printBagFull + "    " + "Backpack weight: " + getTotalWeight() + " / " + maxWeight);
    }
    public static void replaceWeapon(Wapen wapen){
        //replacing weapon if backpack is full
        System.out.println("Your backpack is full. Do you want to replace an item and store " + wapen + "?" + "\n" + "Yes / No");
        String askIfReplaceItem = sc.nextLine();
        int j = 0;
        
        if (askIfReplaceItem.equalsIgnoreCase("Yes")){
            System.out.println("\n" + "__________" + "\n" + "Your backpack: ");
            
            for (Wapen wapenRugzak: weapons){
                System.out.println((j + 1) + ": " + wapenRugzak);
                j++;
            }
            System.out.println("__________");
            System.out.println("What item do you want to replace? ");
            
            int replaceItemIndex = sc.nextInt() - 1;
            
            if (replaceItemIndex >= weapons.size()){
                System.out.println("Invalid index given. Try again.");
                replaceItemIndex = sc.nextInt() - 1;
            }
            else{
                Wapen replacedItem = weapons.get(replaceItemIndex);
                weapons.set(replaceItemIndex, wapen);
                System.out.println("The " + replacedItem.getName() + " has been succesfully replaced by " + wapen.getName() + ".");
            }
        }
    }
    public static ArrayList<Wapen> getWeapons(){
        return weapons;
    }
    public static ArrayList<Aanval> getAttacks(){
        return attacks;
    }
    public static Wapen setWeaponItem(int index, Wapen wapen){
        return weapons.set(index, wapen);
    }
    public void setWeightRugzak(int maxWeight){
        this.maxWeight = maxWeight;
    }
    public static void printRugzak(){
        int j = 0;
        
        System.out.println("\n" + "__________" + "\n" + "Your backpack:");
        System.out.println("Your weapons: ");
        
        if (weapons.size() == 0){
            System.out.println("none");
        }
        for (Wapen wapen: weapons){
            if (wapen != null){
                System.out.println((j + 1) + ": " + wapen.getName());
            }
            j++;
        }
        
        j = 0;
        System.out.println("\n" + "Your attacks: ");
        if (attacks.size() == 0){
            System.out.println("none");
        }
        for (Aanval aanval: attacks){
            System.out.println((j + 1) + ": " + aanval.getName());
            j++;
        }
    }
    public static void printCoins(){
        System.out.println("Your coins: " + coins + " / " + coinPouchSize);
    }
    public static int getCoinPouchSize(){
        return coinPouchSize;
    }
    public static void setCoinPouchSize(int value){
        coinPouchSize = value;
    }
    public static int getCoins(){
        return coins;
    }
    public static void setCoins(int coin){
        if (coin <= coinPouchSize){
            coins = coin;
        }
        else{
            coins = coinPouchSize;
        }
    }
    public static void removeCoins(int coin){
        if (coins - coin < 0){
            coins = 0;
        }
        else{
            coins -= coin;
        }
    }
    public static void printWeapons(){
        int i = 1;
        for (Wapen wapen: weapons){
            if (wapen != null){
                System.out.println(i + ": " + wapen.getName());    
            }
            else{
                System.out.println(i + ": " + "/");
            }
            i++;
        }
    }
    public static void printAttacks(){
        int i = 1;
        for (Aanval aanval: attacks){
            if (aanval != null){
                System.out.println(i + ": " + aanval.getName());    
            }
            else{
                System.out.println(i + ": " + "/");
            }
            i++;
        }
    }
}
