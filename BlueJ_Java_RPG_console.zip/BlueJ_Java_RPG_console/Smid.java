import java.util.*;

public class Smid{
    static Scanner sc = new Scanner(System.in);
    private Random rnd = new Random();
    
    public Smid(){
        
    }
    
    public static void makeChoice(){
        String[] options = {"Upgrade weapon", "Upgrade attack", "Add weapon attack", "Remove weapon attack", "Go back"};
        int choice;
        int optionIndex = 1;
        
        System.out.println("What can I help you with traveler?");
        
        for (String option: options){
            System.out.println(optionIndex + ": " + option);
            optionIndex++;
        }
        try{
            choice = sc.nextInt();
            
            if (choice == 1){
                upgradeWeapon();
                makeChoice();
            }
            else if (choice == 2){
                upgradeAttack();
                makeChoice();
            }
            else if (choice == 3){
                addAttack();
                makeChoice();
            }
            else if (choice == 4){
                removeAttack();
                makeChoice();
            }
            else{
                Spel.makeChoice();
            }
        }
        catch (Exception e){
            System.out.println("Invalid input.");
            sc.nextLine();
            makeChoice();
        }
    }
    public static void upgradeWeapon(){    //makes a weapon (in backpack or in hand of a player) stronger and adds a "+" at the name of the weapon
        int input;
        String input2;
        int price;
        Wapen chosenWeapon;
        
        System.out.println("What weapon do you wanna upgrade?");
        Rugzak.printWeapons();
        Wapen.printAllPlayerWeapons(Rugzak.getWeapons().size() + 1);
        
        input = sc.nextInt();
        sc.nextLine();
        //finding weapon
        if (input <= Rugzak.getWeapons().size() + Spel.getSpelers().length && input > 0){
            if (input <= Rugzak.getWeapons().size()){
                chosenWeapon = Rugzak.getWeapons().get(input - 1);
            }
            else{
                chosenWeapon = Spel.getSpelers()[input - Rugzak.getWeapons().size() - 1].getWeapon();
            }
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //checking if already upgraded
        if (chosenWeapon.getIsUpgraded()){
            System.out.println("You cannot upgrade an already upgraded weapon!");
            return;
        }
        
        //checking if weapon is fists
        if (chosenWeapon.getName().contains("Fists")){
            System.out.println("You cannot upgrade your fists!");
            return;
        }
        
        //determining price to upgrade
        if (chosenWeapon.getRarity().equals(Voorwerp.rarities[0])){
            price = 80;
        }
        else if (chosenWeapon.getRarity().equals(Voorwerp.rarities[1])){
            price = 100;
        }
        else if (chosenWeapon.getRarity().equals(Voorwerp.rarities[2])){
            price = 120;
        }
        else if (chosenWeapon.getRarity().equals(Voorwerp.rarities[3])){
            price = 140;
        }
        else{
            System.out.println("Rarity of weapon not found.");
            return;
        }
        
        System.out.println("Upgrading this " + chosenWeapon.getRarity() + " " + chosenWeapon.getName() + " will cost you " + price + " coins." + "\n" +
        "Do you want to upgrade your " + chosenWeapon.getName() + "?" + " Y / N");
        
        input2 = sc.nextLine();
        if (input2.equalsIgnoreCase("Y") || input2.equalsIgnoreCase("Yes")){
            if (Rugzak.getCoins() >= price){
                double oldCritChance = chosenWeapon.getCritChance();
                String oldName = chosenWeapon.getName();
                int oldSize = chosenWeapon.getAanvallen().length;
                Aanval[] newAttacks = new Aanval[oldSize + 1];
                
                Rugzak.setCoins(Rugzak.getCoins() - price);
                
                chosenWeapon.setName(chosenWeapon.getName() + "+");
                System.arraycopy(chosenWeapon.getAanvallen(), 0, newAttacks, 0, chosenWeapon.getAanvallen().length);
                chosenWeapon.setAanvallen(newAttacks);
                chosenWeapon.setCritChance(chosenWeapon.getCritChance() + ((chosenWeapon.getCritChance() / 100 * 50))); //+ 50% crit chance
                
                chosenWeapon.setIsUpgraded(true);
                
                //printing old --> new stats
                System.out.println("Succesfully upgraded the " + oldName + "." + "\n");
                System.out.println("__________" + "\n" + "New stats:" + "\n" + 
                "Name: " + oldName + " --> " + chosenWeapon.getName() + "\n" + 
                "Crit chance: " + oldCritChance + " --> " + chosenWeapon.getCritChance() + "\n" + 
                "Attack slots: " + oldSize + " --> " + chosenWeapon.getAanvallen().length + "\n");
            }
            else{
                System.out.println("You don't have enough money!");
                return;
            }
        }
        else{
            System.out.println("You canceled upgrading the " + chosenWeapon.getName() + ".");
            return;
        }
    }
    public static void upgradeAttack(){    //makes an attack (in backpack or on a weapon of a player) stronger and adds a "+" at the name of the attack
        int input;
        String input2;
        int price;
        Aanval chosenAttack = null;
        boolean isFound = false;
        
        System.out.println("What attack do you wanna upgrade?");
        Rugzak.printAttacks();
        Aanval.printAllPlayerAttacks(Rugzak.getAttacks().size() + 1);
        
        input = sc.nextInt();
        sc.nextLine();
        //finding weapon
        if (input <= Rugzak.getAttacks().size() + Aanval.getAllPlayerAttacksEquipped() && input > 0){   //Rugzak = 5, AttacksEquipped = 7, aantal spelers = 3: 2 3 2, input = 8
            if (input <= Rugzak.getAttacks().size()){
                chosenAttack = Rugzak.getAttacks().get(input - 1);
            }
            else{
                int waarde = 1;
                for (Speler speler: Spel.getSpelers()){
                    for (Aanval aanval: speler.getWeapon().getAanvallen()){
                        if (input - Rugzak.getAttacks().size() == waarde){
                            if (aanval != null){
                                if (speler.getWeapon().getName().contains("Fists")){
                                    System.out.println("You cannot upgrade attacks that are attached on your fists!");
                                    return;
                                }
                                
                                chosenAttack = aanval;
                                break;
                            }
                            else{
                                System.out.println("Attack not found on index " + input + ".");
                                isFound = true;
                                return;
                            }
                        }
                        waarde++;
                    }
                    if (isFound){
                        break;
                    }
                }
            }
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //checking for existence of chosenAttack
        if (chosenAttack == null){
            System.out.println("Attack not found.");
            return;
        }
        
        //checking if already upgraded
        if (chosenAttack.getIsUpgraded()){
            System.out.println("You cannot upgrade an already upgraded weapon!");
            return;
        }
        
        //determining price to upgrade
        if (chosenAttack.getRarity().equals(Voorwerp.rarities[0])){
            price = 80;
        }
        else if (chosenAttack.getRarity().equals(Voorwerp.rarities[1])){
            price = 100;
        }
        else if (chosenAttack.getRarity().equals(Voorwerp.rarities[2])){
            price = 120;
        }
        else if (chosenAttack.getRarity().equals(Voorwerp.rarities[3])){
            price = 140;
        }
        else{
            System.out.println("Rarity of weapon not found.");
            return;
        }
        
        System.out.println("Upgrading this " + chosenAttack.getRarity() + " " + chosenAttack.getName() + " will cost you " + price + " coins." + "\n" +
        "Do you want to upgrade your " + chosenAttack.getName() + "?" + " Y / N");
        
        input2 = sc.nextLine();
        if (input2.equalsIgnoreCase("Y") || input2.equalsIgnoreCase("Yes")){
            if (Rugzak.getCoins() >= price){
                String oldName = chosenAttack.getName();
                int oldWaarde = chosenAttack.getWaarde();
                
                Rugzak.setCoins(Rugzak.getCoins() - price);
                
                chosenAttack.setName(oldName + "+");
                chosenAttack.setWaarde((int) (oldWaarde + oldWaarde * 0.2));
                
                chosenAttack.setIsUpgraded(true);
                
                //printing old --> new stats
                System.out.println("Succesfully upgraded the " + oldName + "." + "\n");
                System.out.println("__________" + "\n" + "New stats:" + "\n" + 
                "Name: " + oldName + " --> " + chosenAttack.getName() + "\n" + 
                "Damage / Heal: " + oldWaarde + " --> " + chosenAttack.getWaarde() + "\n");
            }
            else{
                System.out.println("You don't have enough money!");
                return;
            }
        }
        else{
            System.out.println("You canceled upgrading the " + chosenAttack.getName() + ".");
            return;
        }
    }
    public static void addAttack(){        //adds an attack in backpack onto a weapon (at least 1 category has to overlap to be succesful)
        int inputWeapon;
        int inputAttack;
        boolean isFound = false;
        boolean isValidCategory = false;
        
        Wapen chosenWeapon;
        Aanval chosenAttack = null;
        
        //printing weapons
        System.out.println("On what weapon do you want to add an attack?");
        Rugzak.printWeapons();
        Wapen.printAllPlayerWeapons(Rugzak.getWeapons().size() + 1);
        
        inputWeapon = sc.nextInt();
        sc.nextLine();
        //finding weapon
        if (inputWeapon <= Rugzak.getWeapons().size() + Spel.getSpelers().length && inputWeapon > 0){
            if (inputWeapon <= Rugzak.getWeapons().size()){
                chosenWeapon = Rugzak.getWeapons().get(inputWeapon - 1);
            }
            else{
                chosenWeapon = Spel.getSpelers()[inputWeapon - Rugzak.getWeapons().size() - 1].getWeapon();
            }
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //printing attacks
        System.out.println("What attack do you want to attach onto " + chosenWeapon.getName() + "?");
        Rugzak.printAttacks();
        
        inputAttack = sc.nextInt();
        sc.nextLine();
        //finding attack
        if (inputAttack <= Rugzak.getAttacks().size() && inputAttack > 0){   //Rugzak = 5, AttacksEquipped = 7, aantal spelers = 3: 2 3 2, input = 8
            chosenAttack = Rugzak.getAttacks().get(inputAttack - 1);
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //checking for existence of chosenAttack
        if (chosenAttack == null){
            System.out.println("Attack not found.");
            return;
        }
        
        //checking if attack is valid category for weapon
        for (String wCategory: chosenWeapon.getCategoriën()){
            for (String aCategory: chosenAttack.getCategoriën()){
                if (wCategory.equals(aCategory)){
                    isValidCategory = true;
                    break;
                }
            }
            if (isValidCategory){
                break;
            }
        }
        if (!isValidCategory){
            System.out.println("It's not possible to attach " + chosenAttack.getName() + " onto " + chosenWeapon.getName() + "!");
            return;
        }
        
        //looking if there is an empty spot to attach the attack on
        //if there is a valid spot, attaches the attack on that spot
        int i = 0;
        boolean isAttached = false;
        for (Aanval aanval: chosenWeapon.getAanvallen()){
            if (aanval == null){
                chosenWeapon.setAanval(i, chosenAttack);
                isAttached = true;
                System.out.println("Succesfully attached " + chosenAttack.getName() + " onto " + chosenWeapon.getName() + " on place " + (i + 1) + ".");
                return;
            }
            i++;
        }
        if (!isAttached){
            System.out.println("No empty slot found on " + chosenWeapon.getName() + " to attach " + chosenAttack.getName() + " onto.");
            return;
        }
    }
    public static void removeAttack(){
        int inputWeapon;
        int inputAttack;
        int price = 30;
        String input;
        boolean isFound = false;
        
        Wapen chosenWeapon;
        Aanval chosenAttack = null;
        
        //printing weapons
        System.out.println("On what weapon do you want to remove an attack?");
        Rugzak.printWeapons();
        Wapen.printAllPlayerWeapons(Rugzak.getWeapons().size() + 1);
        
        inputWeapon = sc.nextInt();
        sc.nextLine();
        //finding weapon
        if (inputWeapon <= Rugzak.getWeapons().size() + Spel.getSpelers().length && inputWeapon > 0){
            if (inputWeapon <= Rugzak.getWeapons().size()){
                chosenWeapon = Rugzak.getWeapons().get(inputWeapon - 1);
            }
            else{
                chosenWeapon = Spel.getSpelers()[inputWeapon - Rugzak.getWeapons().size() - 1].getWeapon();
                
                if (chosenWeapon.getName().contains("Fists")){
                    System.out.println("You cannot remove attacks from fists!");
                    return;
                }
            }
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //weapon needs at least 1 attack check
        int amountOfAttacks = 0;
        for (Aanval aanval: chosenWeapon.getAanvallen()){
            if (aanval != null){
                amountOfAttacks++;
            }
        }
        if (amountOfAttacks <= 1){
            System.out.println("A weapon needs at least one attack!");
            return;
        }
        
        //printing attacks
        System.out.println("What attack do you want to remove?");
        chosenWeapon.printAttacksFromWeapon(chosenWeapon.getAanvallen());
        
        inputAttack = sc.nextInt();
        sc.nextLine();
        //finding weapon
        if (inputAttack <= chosenWeapon.getAanvallen().length && inputAttack > 0){   //Rugzak = 5, AttacksEquipped = 7, aantal spelers = 3: 2 3 2, input = 8
            chosenAttack = chosenWeapon.getAanvallen()[inputAttack - 1];
        }
        else{
            System.out.println("Invalid input.");
            return;
        }
        
        //checking for existence of chosenAttack
        if (chosenAttack == null){
            System.out.println("Attack not found.");
            return;
        }
        
        //asking to proceed
        System.out.println("Removing an attack costs " + price + " coins. Do you want to remove " + chosenAttack.getName() + "? " + "Y / N");
        input = sc.nextLine();
        
        //removing the attack
        if (input.equalsIgnoreCase("Y") || input.equalsIgnoreCase("Yes")){
            if (Rugzak.getCoins() >= price){
                Rugzak.setCoins(Rugzak.getCoins() - price);
                chosenWeapon.setAanval(inputAttack - 1, null);
                System.out.println("Succesfully removed " + chosenAttack.getName() + ".");
            }
            else{
                System.out.println("You don't have enough money!");
                return;
            }
        }
        else{
            System.out.println("You canceled removing " + chosenAttack.getName() + ".");
            return;
        }
    }
    public static void printGreeting(){
        System.out.println("Greetings traveler! Welcome at my smithy!");
    }
    public static void printLeaving(){
        System.out.println("Hopefully see you soon...");
    }
    public static void fullSmithy(){
        Spel.setPlayerLocation("Smithy");
        makeChoice();
    }
}