import java.util.Scanner;
import java.util.Random;

public class Spel{
    private static Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    private static Speler[] spelers;
    private static Vijand[] vijanden;
    
    private static String[] locations = {"Camp", "Forest", "Shop"};
    private static String playerLocation;
    
    Vijand enemyTarget;
    Speler playerTarget;
    
    static int amountOfPlayers = 0;
    static String input;
    static private int overflowCheck;
    
    public static void determinePlayers(){
        System.out.println("With how many players do you wanna play?");
        
        int amountPlayers = sc.nextInt();
        sc.nextLine(); // --> onzichtbaar teken bug tegenhouden
        amountOfPlayers = amountPlayers;
        
        spelers = new Speler[amountOfPlayers];
        
        System.out.println("Type the names of the players in the console.");
        for (int i = 0; i < amountOfPlayers; i++){
            String naam = sc.nextLine();
            spelers[i] = new Speler(naam); // 0 --> 100 for testing
        }
        System.out.println("Done!");
    }
    public static void determineEnemies(){
        //generating amount of enemies
        int amountOfEnemies = rnd.nextInt(3) + 1;
        vijanden = new Vijand[amountOfEnemies];
        
        //generating enemies themselves
        for (int i = 0; i < amountOfEnemies; i++){
            Vijand chosenVijand = Vijand.getAllEnemies()[rnd.nextInt(Vijand.getAllEnemies().length)];
            vijanden[i] = new Vijand(chosenVijand.getEnemyKind(), chosenVijand.getAantalLevens(), chosenVijand.getBaseCoinDrop(), chosenVijand.getAanvallen());
        }
    }
    public static void playGame(){
        //basic info
        System.out.println("Hello, I welcome you to this simple RPG game." + "\n" +
        "You will need to fight off a diverse amount of enemies, it's not gonna be easy." + "\n");
        
        determinePlayers();
        
        if (spelers.length > 1){
            System.out.println("Looks like you chose to play with " + spelers.length + " players.");
        }
        else{
            System.out.println("Looks like you chose to play alone.");
        }
        
        //starting game
        System.out.println("Let's begin with a simple battle.");
        System.out.println("Write 'Start' in the console to begin your adventure.");
        
        String input = sc.nextLine();
        if (input.equalsIgnoreCase("start")){
            System.out.println("You started the game.");
        }
        else{
            while (!(input.equalsIgnoreCase("Start"))){
                input = sc.nextLine();
            }
        }
        
        battle();
    }
    public static void battle(){
        //setting location
        playerLocation = "Forest";
        
        //creating enemies
        determineEnemies();
        printEnemyStats();
        
        //game itself
        while (true){ //loops the game as long as not a whole team died
            //loop for players
            System.out.println("__________" + "\n" + "Your turn!" + "\n");
            for (int i = 0; i < spelers.length; i++){
                if (!spelers[i].isDead()){
                    chooseEnemy(spelers[i]);
                    spelers[i].chooseAttack();
                    spelers[i].attack();
                    
                    for (int j = 0; j < vijanden.length; j++){
                        checkIfEnemyIsDead(vijanden[j]);
                    }
                    if (checkIfAllEnemiesDead()){
                        printYouWon();
                        Rugzak.dropLoot();
                        makeChoice();
                        return;
                    }
                }
                else{
                    int chooseLine = rnd.nextInt(3);
                    
                    switch(chooseLine){
                        case 0: System.out.println(spelers[i].getName() + " is dead. " + spelers[i].getName() + " cannot attack anymore in this battle."); break;
                        case 1: System.out.println(spelers[i].getName() + " died. That means that " + spelers[i].getName() + " cannot attack anymore in this battle."); break;
                        case 2: System.out.println(spelers[i].getName() + " will not wake up anymore. " + spelers[i].getName() + " will not be able to attack anymore in this battle."); break;
                    }
                }
            }
            
            //loop for enemies
            System.out.println("__________" + "\n" + "Enemy's turn!" + "\n");
            for (int i = 0; i < vijanden.length; i++){
                if (!vijanden[i].isDood()){
                    choosePlayer(vijanden[i]);
                    vijanden[i].attack();
                    vijanden[i].printDamageThisRound();
                    vijanden[i].doDamageOverTime(); //does DoT damage
                    for (int j = 0; j < spelers.length; j++){
                        checkIfPlayerIsDead(spelers[j]);
                    }
                    if (checkIfAllPlayersDead()){
                        printYouLost();
                        makeChoice();
                        return;
                    }
                }
                else{
                    int chooseLine = rnd.nextInt(3);
                    
                    switch(chooseLine){
                        case 0: System.out.println(vijanden[i].getName() + " is dead. " + vijanden[i].getName() + " cannot attack anymore in this battle."); break;
                        case 1: System.out.println(vijanden[i].getName() + " died. That means that " + vijanden[i].getName() + " cannot attack anymore in this battle."); break;
                        case 2: System.out.println(vijanden[i].getName() + " will not wake up anymore. " + vijanden[i].getName() + " will not be able to attack anymore in this battle."); break;
                    }
                }
            }
            printPlayerStats();
        }
    }
    public static String makeChoice(){
        String choice;
        int option = 1;
        String returnValue;
        
        //prints the locations
        System.out.println("__________" + "\n" + "Where do you wanna go now? " + "\n" + "Possible choices: " + "\n");
        for (String location: locations){
            if (playerLocation.equals(location)){
                System.out.println(option + ": " + location + " (You're here!)");
            }
            else{
                System.out.println(option + ": " + location);
            }
            
            option++;
        }
        
        //player makes choice between locations
        choice = sc.nextLine();
        
        if (choice.equalsIgnoreCase(locations[0]) || choice.equals("1")){
            System.out.println("Traveling to " + "Camp" + "...");
            returnValue = locations[0];
            Spel.playerLocation = locations[0];
            Kamp.fullCamp();
        }
        else if(choice.equalsIgnoreCase(locations[1]) || choice.equals("2")){
            System.out.println("Traveling to " + "Forest" + "...");
            returnValue = locations[1];
            Spel.playerLocation = locations[1];
            battle();
        }
        else if(choice.equalsIgnoreCase(locations[2]) || choice.equals("3")){
            System.out.println("Traveling to " + "Shop" + "...");
            returnValue = locations[2];
            Spel.playerLocation = locations[2];
            Winkel.fullShop();
        }
        else{
            System.out.println("Invalid input.");
            returnValue = "Invalid";
        }
        return returnValue;
    }   
    public static void chooseEnemy(Speler speler){
        System.out.println("Which enemy does " + speler.getName() + " need to attack?");
        String enemyName = sc.nextLine();
    
        for (int i = 0; i < vijanden.length; i++){
            if (vijanden[i].getName().equalsIgnoreCase(enemyName)){
                speler.chooseEnemy(vijanden[i]);
                break;
            }
        }
    }
    public static void choosePlayer(Vijand vijand){
        for (int i = 0; i < spelers.length; i++){
            int getal = rnd.nextInt(spelers.length);
            vijand.choosePlayer(spelers[getal]);
            
        }
    }
    public static int getOverflowCheck(){
        return overflowCheck;
    }
    public static void checkIfEnemyIsDead(Vijand vijand){
        if (vijand.isDood() && vijand.getAantalLevens() == 0){
            System.out.println(vijand.getName() + " died.");
            vijand.setAantalLevens(1);
        }
    }
    public static void checkIfPlayerIsDead(Speler speler){
        if (speler.isDead() && speler.getAmountOfLives() == 0){
            System.out.println(speler.getName() + " died.");
            speler.setAmountOfLives(1);
        }
    }
    public static boolean checkIfAllPlayersDead(){
        boolean allPlayersDead = false;
        int checkIfAllDead = 0;
        for (int i = 0; i < spelers.length; i++){
            if (spelers[i].isDead()){
                checkIfAllDead++;
            }
        }
        if (checkIfAllDead == spelers.length){
            allPlayersDead = true;
        }
        return allPlayersDead;
    }
    public static boolean checkIfAllEnemiesDead(){
        boolean allEnemiesDead = false;
        int checkIfAllDead = 0;
        for (int i = 0; i < vijanden.length; i++){
            if (vijanden[i].isDood()){
                checkIfAllDead++;
            }
        }
        if (checkIfAllDead == vijanden.length){
            allEnemiesDead = true;
        }
        return allEnemiesDead;
    }
    public static void setOverflowCheck(int overflowChecken){
        overflowCheck = overflowChecken;
    }
    public static void printEnemyStats(){
        System.out.println("__________" + "\n" + "Enemies:");
        for (int i = 0 ; i < vijanden.length && vijanden[i] != null; i++){
            if (vijanden[i].isDood()){
                System.out.println(vijanden[i].getName() + ", " + vijanden[i].getEnemyKind() + " (dead)");
            }
            else{
                System.out.println(vijanden[i].getName() + ", " + vijanden[i].getEnemyKind() + " (" + vijanden[i].getAantalLevens() + " hp)");
            }
        }
        System.out.println("__________");
    }
    public static void printYouWon(){
        int chooseDeathNote = rnd.nextInt(3);
        switch(chooseDeathNote){
            case 0: System.out.println("\n" + "You won! Your team managed to kill all enemies succesfully!"); break;
            case 1: System.out.println("\n" + "You won! Your team was just to strong for these unlucky enemies."); break;
            case 2: System.out.println("\n" + "You won! I just knew your team could do it!"); break;
        }
    }
    public static void printYouLost(){
        int chooseDeathNote = rnd.nextInt(3);
        switch(chooseDeathNote){
            case 0: System.out.println("\n" + "You lost. The enemies managed to kill your team."); break;
            case 1: System.out.println("\n" + "You Lost. You got overwhelmed by the enemies."); break;
            case 2: System.out.println("\n" + "You lost. The enemies were just to strong for your team."); break;
        }
    }
    public static Vijand[] getVijanden(){
        return vijanden;
    }
    public static Speler[] getSpelers(){
        return spelers;
    }
    public static String getPlayerLocation(){
        return playerLocation;
    }
    public static void setPlayerLocation(String location){
        playerLocation = location;
    }
    public static void printSpelers(){
        System.out.println("\n" + "__________" + "\n" + "Your team: ");
        int j = 0;
        for (Speler speler: spelers){
            System.out.println((j + 1) + ": " + speler.getName());
            j++;
        }
    }
    public static void printPlayerStats(){
        System.out.println("\n" + "__________" + "\n" + "Your team: ");
        int i = 0;
        for (Speler speler: spelers){
            if (spelers[i].isDead()){
                System.out.println((i + 1) + ": " + spelers[i].getName() + ", " + " (dead)");
            }
            else{
                System.out.println((i + 1) + ": " + spelers[i].getName() + ", " + " (" + spelers[i].getAmountOfLives() + " hp)");
            }
            i++;
        }
    }
    public static void printPlayerWeapons(){
        System.out.println("\n" + "__________" + "\n" + "Your team's weapons equipped: ");
        int i = 0;
        for (Speler speler: spelers){
            System.out.println((i + 1) + ": " + spelers[i].getName() + ", " + " (" + speler.getWeapon().getWeaponName() + ")");
            i++;
        }
    }
}