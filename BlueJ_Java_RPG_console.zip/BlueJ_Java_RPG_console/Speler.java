import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class Speler
{
    private String name = "Unknown";
    private int maxAmountOfLives;
    private int amountOfLives;
    private Vijand vijand;
    private boolean isDead = false;
    private Vijand huidigeVijand;
    private Wapen weapon;
    
    private int damageOverTime = 0;
    
    private Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public Speler(String name){
        this.name = name;
        weapon = Wapen.getAllWeapons()[0];
        Aanval.determineBaseAttacks(weapon);
        amountOfLives = 100;
    }
    public void chooseEnemy(Vijand vijand){
        this.vijand = vijand;
        huidigeVijand = vijand;
        
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            vijand.choosePlayer(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public boolean isDead(){
        if (amountOfLives <= 0){
            isDead = true;
        }
        return isDead;
    }
    public void setAmountOfLives(int amountOfLives){
        this.amountOfLives = amountOfLives;
    }
    public int getAmountOfLives(){
        return amountOfLives;
    }
    public Vijand huidigeVijand(){
        return huidigeVijand;
    }
    
    public void attack(){
        int j = 0;
        
        //damage
        if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Damage")){
            weapon.calculateDamage();
            checkDamageOne();
            checkDamageAll();
            printDamageThisRound();
        }
        //heal
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Heal")){
            weapon.calculateDamage();
            checkHeal();
        }
        //buff
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Buff")){
            
        }
    }
    public void checkDamageAll(){
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage All")){
            for (Vijand vijandje: Spel.getVijanden()){
                if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Normal")){
                    vijandje.setAmountOfLives(vijandje.getAmountOfLives() - weapon.getDamageThisRound());
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Damage Over Time")){
                    vijandje.setAmountOfLives(vijandje.getAmountOfLives() - weapon.getDamageThisRound());
                    vijandje.setDamageOverTime(vijandje.getDamageOverTime() + 2);
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Final Hit")){
                    if (vijandje.getAmountOfLives() <= 50){
                        weapon.setDamageThisRound(weapon.getChosenAttack().getWaarde() * 2);
                        vijandje.setAmountOfLives(vijandje.getAmountOfLives() - weapon.getDamageThisRound());
                    }
                    else{
                        vijandje.setAmountOfLives(vijandje.getAmountOfLives() - weapon.getDamageThisRound());
                    }
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
                    for (int i = 0; i < 2; i++){
                        vijandje.setAmountOfLives(vijandje.getAmountOfLives() - weapon.getDamageThisRound());
                    }
                }
                else{
                    System.out.println("Damage effect not found.");
                }
                
                if (vijand.getAmountOfLives() < 0){
                    vijand.setAmountOfLives(0);
                }
            }
        }
    }
    public void checkDamageOne(){
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage One")){
            if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Normal")){
                    vijand.setAmountOfLives(vijand.getAmountOfLives() - weapon.getDamageThisRound());
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Damage Over Time")){
                vijand.setAmountOfLives(vijand.getAmountOfLives() - weapon.getDamageThisRound());
                vijand.setDamageOverTime(vijand.getDamageOverTime() + 2);
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Final Hit")){
                if (vijand.getAmountOfLives() <= 50){
                    weapon.setDamageThisRound(weapon.getChosenAttack().getWaarde() * 2);
                    vijand.setAmountOfLives(vijand.getAmountOfLives() - weapon.getDamageThisRound());
                }
                else{
                    vijand.setAmountOfLives(vijand.getAmountOfLives() - weapon.getDamageThisRound());
                }
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
                for (int i = 0; i < 2; i++){
                    vijand.setAmountOfLives(vijand.getAmountOfLives() - weapon.getDamageThisRound());
                }
            }
            else{
                System.out.println("Damage effect not found.");
            }
            
            if (vijand.getAmountOfLives() < 0){
                vijand.setAmountOfLives(0);
            }
        }
    }
    public void checkHeal(){
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Heal Self")){
            setAmountOfLives(weapon.getDamageThisRound());
        }
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Heal All")){
            for (Speler speler: Spel.getSpelers()){
                if (!speler.isDead()){
                    speler.setAmountOfLives(weapon.getDamageThisRound());
                }
            }
        }
        else{
            System.out.println("Heal effect not found.");
        }
    }
    public void chooseAttack(){
        boolean isValidInput = false;
        
        while (!isValidInput){
            System.out.println("What attack does " + name + " need to use?");
            weapon.printAttacksFromWeapon(weapon.getAanvallen());
            
            try{
                int chosenAttackIndex = sc.nextInt() - 1;
                
                if (weapon.getAanvallen()[chosenAttackIndex] != null){
                    isValidInput = true;
                    weapon.setChosenAttack(weapon.getAanvallen()[chosenAttackIndex]);
                }
            }
            catch(Exception e){
                System.out.println("Attack not found. Try again.");
                sc.nextLine();
            }
        }
    }
    
    public String getName(){
        return name;
    }
    public void printDamageThisRound(){
        String multiHitText = "";
        
        if(weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
            multiHitText = " (x 2)";
        }
        
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage One")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to " + vijand.getName() + " this round." + multiHitText);
        }
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage All")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to everyone this round." + multiHitText);
        }
    }
    public void doDamageOverTime(){
        if (damageOverTime > 0){
            amountOfLives -= 5;
            damageOverTime--;
            if (amountOfLives < 0){
                amountOfLives = 0;
            }
            printDamageOverTime();
        }
    }
    public void printDamageOverTime(){
        if (amountOfLives != 0){
            System.out.println(name + " got damaged by a DoT effect for 5 damage. (" + amountOfLives + "hp)");
        }
        else{
            System.out.println(name + " got damaged by a DoT effect for 5 damage. (dead)");
        }
    }
    public Wapen getWeapon(){
        return weapon;
    }
    public void setWeapon(Wapen weapon){
        this.weapon = weapon;
    }
    public int getDamageOverTime(){
        return damageOverTime;
    }
    public void setDamageOverTime(int value){
        damageOverTime = value;
    }
}