import java.util.Random;
import java.util.Scanner;
public class Speler
{
    private String name = "Unknown";
    private int amountOfLives;
    private Vijand vijand;
    private boolean isDead = false;
    private Vijand huidigeVijand;
    private Wapen weapon;

    
    Random rnd = new Random();
    
    public Speler(String name){
        this.name = name;
        weapon = new Wapen("Fists");
        amountOfLives = 100;
    }
    public void chooseEnemy(Vijand vijand){
        this.vijand = vijand;
        huidigeVijand = vijand;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            vijand.choosePlayer(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public boolean isDead(){
        if (amountOfLives <= 0){
            isDead = true;
        }
        return isDead;
    }
    public void setAmountOfLives(int amountOfLives){
        this.amountOfLives = amountOfLives;
    }
    public int getAmountOfLives(){
        return amountOfLives;
    }
    public Vijand huidigeVijand(){
        return huidigeVijand;
    }
    
    public void attack(){
        weapon.setDamageThisRound(weapon.calculateDamage());
        
        isDead();
        if (!isDead && !vijand.isDood()){
            vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
            if(vijand.getAantalLevens() < 0){
                vijand.setAantalLevens(0);           
            }
        }
        printDamageThisRound();
        // Hier valt de speler aan en wordt de vijand schade toegebracht
    }
    
    public String getName(){
        return name;
    }
    public void printDamageThisRound(){
        System.out.println(name + " did do " + weapon.getDamageThisRound() + " damage to " + vijand.getName() + " this round. ");
    }
}
// so the game now is just very simple. There is a player and an enemy.
// you can choose an enemy to fight and then attack him. After you attacked
// he will attack you. WIP.