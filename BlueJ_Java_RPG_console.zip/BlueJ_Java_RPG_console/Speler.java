import java.util.Random;
import java.util.Scanner;
public class Speler
{
    private String name = "Unknown";
    private int amountOfLives;
    private Vijand vijand;
    private boolean isDead = false;
    private Vijand huidigeVijand;
    private Wapen weapon;
    
    private Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public Speler(String name){
        this.name = name;
        weapon = Wapen.getAllWeapons()[0];
        Aanval.determineBaseAttacks(weapon);
        amountOfLives = 100;
    }
    public void chooseEnemy(Vijand vijand){
        this.vijand = vijand;
        huidigeVijand = vijand;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            vijand.choosePlayer(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public boolean isDead(){
        if (amountOfLives <= 0){
            isDead = true;
        }
        return isDead;
    }
    public void setAmountOfLives(int amountOfLives){
        this.amountOfLives = amountOfLives;
    }
    public int getAmountOfLives(){
        return amountOfLives;
    }
    public Vijand huidigeVijand(){
        return huidigeVijand;
    }
    
    public void attack(){
        int j = 0;
        
        //damage
        if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Damage")){
            weapon.setDamageThisRound(weapon.getChosenAttack().getWaarde());
            checkDamageOne();
            checkDamageAll();
            printDamageThisRound();
        }
        //heal
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Heal")){
            
        }
        //buff
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().contains("Buff")){
            
        }
    }
    public void checkDamageAll(){
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage All")){
            for (Vijand vijandje: Spel.getVijanden()){
                if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Normal")){
                    vijandje.setAantalLevens(vijandje.getAantalLevens() - weapon.getDamageThisRound());
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Damage Over Time")){
                    vijandje.setAantalLevens(vijandje.getAantalLevens() - weapon.getDamageThisRound());
                    vijandje.setDamageOverTime(vijandje.getDamageOverTime() + 2);
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Final Hit")){
                    if (vijandje.getAantalLevens() <= 50){
                        weapon.setDamageThisRound(weapon.getChosenAttack().getWaarde() * 2);
                        vijandje.setAantalLevens(vijandje.getAantalLevens() - weapon.getDamageThisRound());
                    }
                    else{
                        vijandje.setAantalLevens(vijandje.getAantalLevens() - weapon.getDamageThisRound());
                    }
                }
                else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
                    for (int i = 0; i < 2; i++){
                        vijandje.setAantalLevens(vijandje.getAantalLevens() - weapon.getDamageThisRound());
                    }
                }
                    
                if (vijand.getAantalLevens() < 0){
                    vijand.setAantalLevens(0);
                }
            }
        }
    }
    public void checkDamageOne(){
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage One")){
            if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Normal")){
                    vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Damage Over Time")){
                vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
                vijand.setDamageOverTime(vijand.getDamageOverTime() + 2);
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Final Hit")){
                if (vijand.getAantalLevens() <= 50){
                    weapon.setDamageThisRound(weapon.getChosenAttack().getWaarde() * 2);
                    vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
                }
                else{
                    vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
                }
            }
            else if (weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
                for (int i = 0; i < 2; i++){
                    vijand.setAantalLevens(vijand.getAantalLevens() - weapon.getDamageThisRound());
                }
            }
            
            if (vijand.getAantalLevens() < 0){
                vijand.setAantalLevens(0);
            }
        }
    }
    public void chooseAttack(){
        System.out.println("What attack does " + name + " need to use?");
        weapon.printAttacksFromWeapon(weapon.getAanvallen());
        
        int chosenAttackIndex = sc.nextInt() - 1;
        weapon.setChosenAttack(weapon.getAanvallen()[chosenAttackIndex]);
    }
    
    public String getName(){
        return name;
    }
    public void printDamageThisRound(){
        String multiHitText = "";
        
        if(weapon.getChosenAttack().getEffect().getSpecialEffect().equals("Multi Hit")){
            multiHitText = " (x 2)";
        }
        
        if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage One")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to " + vijand.getName() + " this round." + multiHitText);
        }
        else if (weapon.getChosenAttack().getEffect().getEffectSoort().equals("Damage All")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to everyone this round." + multiHitText);
        }
    }
    public Wapen getWeapon(){
        return weapon;
    }
    public void setWeapon(Wapen weapon){
        this.weapon = weapon;
    }
}