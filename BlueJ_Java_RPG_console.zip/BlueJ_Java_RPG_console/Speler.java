import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class Speler extends Entiteit
{
    private Vijand huidigeVijand;
    
    private Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public Speler(String name){
        super(name);
        
        try{
            weapon = (Wapen) Wapen.getAllWeapons()[0].clone();
        } 
        catch (CloneNotSupportedException e){
            System.out.println("Somehow something went wrong.");
        }
        
        weapon.determineBaseAttacks();
    }
    public void chooseEnemy(Vijand vijand){
        huidigeVijand = vijand;
        
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            vijand.choosePlayer(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public Vijand getHuidigeVijand(){
        return huidigeVijand;
    }
    
    public void attack(){
        int j = 0;
        
        //damage
        if (weapon.getChosenAttack().getAanvalSoort().contains("Damage")){
            weapon.calculateDamage();
            checkDamage();
            
            //checkDamageOne();
            //checkDamageAll();
            //printDamageThisRound();
        }
        //heal
        else if (weapon.getChosenAttack().getAanvalSoort().contains("Heal")){
            weapon.calculateDamage();
            checkHeal();
            printHealThisRound();
        }
        //buff
        else if (weapon.getChosenAttack().getAanvalSoort().contains("Buff")){
            
        }
    }
    public void checkDamage(){
        try{
            String effectKind = weapon.getChosenAttack().getEffect().getEffectKind();
        
            if (effectKind.equals("Normal")){
                Effect.normal(this);
            }
            else if (effectKind.equals("Damage Over Time")){
                Effect.damageOverTime(this);
                Effect.normal(this);
            }
            else if (effectKind.equals("Multi Hit")){
                Effect.multiHit(this);
            }
            else if (effectKind.equals("Final Hit")){
                Effect.finalHit(this);
            }
            else if (effectKind.equals("Remove Gold")){
                Effect.removeGold(this);
            }
        }
        catch (Exception e){
            Effect.normal(this);
        }
    }
    public void checkHeal(){
        if (weapon.getChosenAttack().getAanvalSoort().equals("Heal Self")){
            setAmountOfLives(weapon.getDamageThisRound());
        }
        else if (weapon.getChosenAttack().getAanvalSoort().equals("Heal All")){
            for (Speler speler: Spel.getSpelers()){
                if (!speler.isDead()){
                    speler.setAmountOfLives(weapon.getDamageThisRound());
                }
            }
        }
        else{
            System.out.println("Heal effect not found.");
        }
    }
    public void chooseAttack(){
        boolean isValidInput = false;
        
        while (!isValidInput){
            System.out.println("What attack does " + name + " need to use?");
            weapon.printAttacksFromWeapon(weapon.getAanvallen());
            
            try{
                int chosenAttackIndex = sc.nextInt() - 1;
                
                if (weapon.getAanvallen()[chosenAttackIndex] != null){
                    isValidInput = true;
                    weapon.setChosenAttack(weapon.getAanvallen()[chosenAttackIndex]);
                }
                else{
                    System.out.println("There's no attack on that slot!");
                }
            }
            catch(Exception e){
                System.out.println("Attack not found. Try again.");
                sc.nextLine();
            }
        }
    }
    
    public void printDamageThisRound(){
        String multiHitText = "";
        
        try{
            if(weapon.getChosenAttack().getEffect().getEffectKind().equals("Multi Hit")){
                multiHitText = " (x" + weapon.getChosenAttack().getEffect().getValue1() + ")";
            }
        }
        catch (Exception e){
            
        }
        if (weapon.getChosenAttack().getAanvalSoort().equals("Damage One")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to " + huidigeVijand.getName() + " this round." + multiHitText);
        }
        else if (weapon.getChosenAttack().getAanvalSoort().equals("Damage All")){
            System.out.println(name + " did " + weapon.getDamageThisRound() + " damage to everyone this round." + multiHitText);
        }
    }
    public void printHealThisRound(){
        String affectedPlayer = "";
        
        if (weapon.getChosenAttack().getAanvalSoort().equals("Heal Self")){
            affectedPlayer = "himself";
            System.out.println(name + " healed " + affectedPlayer + " for " + weapon.getDamageThisRound() + " this round." + affectedPlayer);
        }
        else if (weapon.getChosenAttack().getAanvalSoort().equals("Heal All")){
            affectedPlayer = "everyone";
            System.out.println(name + " healed " + affectedPlayer + " for " + weapon.getDamageThisRound() + " this round." + affectedPlayer);
        }
        else{
            System.out.println("Something went wrong with printing restored health.");
        }
    }
    public void printDotThisRound(){
        String enemiesHit = huidigeVijand.getName();
        String aanvalSoort = weapon.getChosenAttack().getAanvalSoort();
        
        if (aanvalSoort.contains("All")){
            enemiesHit = " everyone";
        }
        
        System.out.println(name + " (" + getAmountOfLives() + " hp) inflicted " + weapon.getChosenAttack().getEffect().getName() + " to " + enemiesHit + ".");
    }
}