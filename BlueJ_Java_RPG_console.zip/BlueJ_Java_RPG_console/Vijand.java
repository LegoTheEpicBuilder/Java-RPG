import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;

public class Vijand extends Entiteit
{
    static String[] enemyKinds = {"Wolf","Wizard","Goblin","Zombie"};
    static String[] allAttacks = {"Claws", "Roar", "Spell", "Healing Drink", "Punch", "Gold Steal", "Bite", "Grab"};
    static String[] possibleNames = {"James", "Robert", "John", "Michael", "David", "William", 
                                "Mary", "Patricia", "Jennifer", "Linda", "Lisa"};
    
    private static Vijand[] allEnemies = new Vijand[]{
    new Vijand("Wolf", 80, 25, new Aanval[]{Aanval.getAllEnemyAttacks()[0], Aanval.getAllEnemyAttacks()[1]}),
    new Vijand("Wizard", 140, 40, new Aanval[]{Aanval.getAllEnemyAttacks()[2], Aanval.getAllEnemyAttacks()[3]}),
    new Vijand("Goblin", 60, 50, new Aanval[]{Aanval.getAllEnemyAttacks()[4], Aanval.getAllEnemyAttacks()[5]}),
    new Vijand("Zombie", 100, 30, new Aanval[]{Aanval.getAllEnemyAttacks()[6], Aanval.getAllEnemyAttacks()[7]})
    };
    
    //TBA
    private int baseCoinDrop;
    private int coinDropThisRound;
    
    private String enemyKind;
    private Speler huidigeSpeler;
    
    private Random rnd = new Random();
    
    public Vijand(String enemyKind, int amountOfLives, int baseCoinDrop, Aanval[] aanvallen){
        super(amountOfLives);
        this.enemyKind = enemyKind;
        this.amountOfLives = amountOfLives;
        this.baseCoinDrop = baseCoinDrop;
        this.weapon = new Wapen("", 10, new String[]{"All"}, new Aanval[]{aanvallen[0], aanvallen[1]}, 0, "Common");  //Wapen.getAllWeapons()[0]
        
        maxAmountOfLives = amountOfLives;
        determineName();
    }
    public void choosePlayer(Speler speler){
        huidigeSpeler = speler;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            speler.chooseEnemy(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public void chooseAttack(){
        weapon.setChosenAttack(weapon.getAanvallen()[rnd.nextInt(weapon.getAanvallen().length)]);
    }
    public void attack(){
        int j = 0;
        
        chooseAttack();
        String aanvalSoort = weapon.getChosenAttack().getAanvalSoort();
        
        //damage
        if (aanvalSoort.contains("Damage")){
            calculateDamage();
            checkDamage();
            //checkDamageOne();
            //checkDamageAll();
        }
        //heal
        else if (aanvalSoort.contains("Heal")){
            calculateDamage();
            checkHeal();
        }
        //buff
        else if (aanvalSoort.contains("Buff")){
            System.out.println(getEnemyKind() + " " + getName() + " (" + getAmountOfLives() + " hp)" + " Buffs not implemented yet.");
        }
        else if (aanvalSoort.contains("Debuff")){
            System.out.println(getEnemyKind() + " " + getName() + " (" + getAmountOfLives() + " hp)" + " Debuffs not implemented yet.");
        }
        else{
            System.out.println(getEnemyKind() + " " + getName() + " (" + getAmountOfLives() + " hp)" + " kind of attack not found.");
        }
    }
    public void checkDamage(){
        try{
            String effectKind = weapon.getChosenAttack().getEffect().getEffectKind();
        
            if (effectKind.equals("Normal")){
                Effect.normal(this);
            }
            else if (effectKind.equals("Damage Over Time")){
                Effect.damageOverTime(this);
                Effect.normal(this);
            }
            else if (effectKind.equals("Multi Hit")){
                Effect.multiHit(this);
            }
            else if (effectKind.equals("Final Hit")){
                Effect.finalHit(this);
            }
            else if (effectKind.equals("Remove Gold")){
                Effect.removeGold(this);
            }
        }
        catch (Exception e){
            Effect.normal(this);
        }
    }
    public void checkHeal(){
        String aanvalSoort = weapon.getChosenAttack().getAanvalSoort();
        
        if (aanvalSoort.equals("Heal Self")){
            setAmountOfLives(amountOfLives + weapon.getDamageThisRound());
            System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp)" + " healed himself for " + weapon.getDamageThisRound() + " hp.");
        }
        else if (aanvalSoort.equals("Heal All")){
            for (Vijand vijand: Spel.getVijanden()){
                if (!vijand.isDead()){
                    vijand.setAmountOfLives(vijand.getAmountOfLives() + weapon.getDamageThisRound());
                    System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp)" + " healed everyone for " + weapon.getDamageThisRound() + " hp.");
                }
            }
        }
        else{
            System.out.println("Heal effect not found.");
        }
    }
    public void calculateDamage(){
        weapon.setDamageThisRound((int) Math.round((0.8 + Math.random() * (1.2 - 0.8)) * weapon.getChosenAttack().getWaarde()));
    }
    public Speler huidigeSpeler(){
        return huidigeSpeler;
    }
    public String getEnemyKind(){
        return enemyKind;
    }
    public int calculateCoinDrop(){
        double randomFactor = rnd.nextDouble() * 0.4 + 0.8; // genereert een getal tussen 0.8 en 1.2
        coinDropThisRound = (int) Math.round(baseCoinDrop * randomFactor);
        
        return coinDropThisRound;
    }
    public String determineName(){
        // "James", "Robert", "John", "Michael", "David", "William" | "Mary", "Patricia", "Jennifer", "Linda", "Lisa"
        // bro this method took me so long to write and it finally works
        List<String> possibleNamesArrayList = new ArrayList<>(Arrays.asList(possibleNames));
        
        int choosingNameIndex = rnd.nextInt(possibleNamesArrayList.size());
        name = possibleNames[choosingNameIndex];
        
        possibleNamesArrayList.subList(choosingNameIndex, choosingNameIndex + 1).clear();
        possibleNames = possibleNamesArrayList.toArray(new String[possibleNamesArrayList.size()]);
        
        return name;
    }
    public void printDamageThisRound(){
        String playersHit = huidigeSpeler.getName();
        String aanvalSoort = weapon.getChosenAttack().getAanvalSoort();
        
        if (aanvalSoort.contains("All")){
            playersHit = " everyone";
        }
        if (aanvalSoort.contains("Damage")){
            System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp)" + " did " + weapon.getDamageThisRound() + " damage with his attack " + weapon.getChosenAttack().getName() + " to " + playersHit + ". ");
        }
        else if (aanvalSoort.contains("Heal")){
            if (playersHit.equals(huidigeSpeler.getName())){
                playersHit = " himself";
            }
            else{
                playersHit = " everyone from his team";
            }
            System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp) healed" + playersHit + " for " + weapon.getDamageThisRound() + ". ");
        }
        else{
            System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp) did something.");
        }
    }
    public void printDotThisRound(){
        String playersHit = huidigeSpeler.getName();
        String aanvalSoort = weapon.getChosenAttack().getAanvalSoort();
        
        if (aanvalSoort.contains("All")){
            playersHit = " everyone";
        }
        
        System.out.println(enemyKind + " " + name + " (" + getAmountOfLives() + " hp) inflicted " + weapon.getChosenAttack().getEffect().getName() + " to " + playersHit + ".");
    }
    public void printBaseCoinDrop(){
        System.out.println(baseCoinDrop);
    }
    public static Vijand[] getAllEnemies(){
        return allEnemies;
    }
    public int getBaseCoinDrop(){
        return baseCoinDrop;
    }
    public Speler getHuidigeSpeler(){
        return huidigeSpeler;
    }
    public void setHuidigeSpeler(Speler huidigeSpeler){
        this.huidigeSpeler = huidigeSpeler;
    }
}