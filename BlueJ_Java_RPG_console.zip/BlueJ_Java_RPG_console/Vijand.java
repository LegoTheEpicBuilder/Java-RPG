import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Scanner;

public class Vijand
{
    static String[] enemyKinds = {"Wolf","Wizard","Goblin","Zombie"};
    static String[] allAttacks = {"Claws", "Roar", "Spell", "Healing Drink", "Punch", "Gold Steal", "Bite", "Grab"};
    static String[] possibleNames = {"James", "Robert", "John", "Michael", "David", "William", 
                                "Mary", "Patricia", "Jennifer", "Linda", "Lisa"};
    
    private static Vijand[] allEnemies = new Vijand[]{
    new Vijand("Wolf", 80, 25, new Aanval[]{Aanval.getAllEnemyAttacks()[0], Aanval.getAllEnemyAttacks()[1]}),
    new Vijand("Wizard", 140, 40, new Aanval[]{Aanval.getAllEnemyAttacks()[2], Aanval.getAllEnemyAttacks()[3]}),
    new Vijand("Goblin", 60, 50, new Aanval[]{Aanval.getAllEnemyAttacks()[4], Aanval.getAllEnemyAttacks()[5]}),
    new Vijand("Zombie", 100, 30, new Aanval[]{Aanval.getAllEnemyAttacks()[6], Aanval.getAllEnemyAttacks()[7]})
    };
    
    private Aanval[] aanvallen = new Aanval[2];
    private Aanval attackThisRound;
    private int damageThisRound;
    private String naam = "Unknown";
    
    //TBA
    private int baseCoinDrop;
    private int coinDropThisRound;
    
    private int damageOverTime = 0;
    
    
    private int aantalLevens;
    private boolean isDood = false;
    private Speler speler;
    private int gemiddeldeSchade = 15;
    private String enemyKind;
    private Speler huidigeSpeler;
    
    Random rnd = new Random();
    
    public Vijand(String enemyKind, int aantalLevens, int baseCoinDrop, Aanval[] aanvallen){
        this.enemyKind = enemyKind;
        this.aantalLevens = aantalLevens;
        this.baseCoinDrop = baseCoinDrop;
        this.aanvallen = aanvallen;
        determineName();
    }
    public void choosePlayer(Speler speler){
        this.speler = speler;
        huidigeSpeler = speler;
        if (Spel.getOverflowCheck() == 0){
            Spel.setOverflowCheck(1);
            speler.chooseEnemy(this);
        }
        else{
            Spel.setOverflowCheck(0);
        }
    }
    public void chooseAttack(){
        attackThisRound = aanvallen[rnd.nextInt(aanvallen.length)];
    }
    public boolean isDood(){
        if (aantalLevens <= 0){
            isDood = true;
        }
        return isDood;
    }
    public void attack(){
        int j = 0;
        
        chooseAttack();
        
        //damage
        if (attackThisRound.getEffect().getEffectSoort().contains("Damage")){
            calculateDamage();
            checkDamageOne();
            checkDamageAll();
        }
        //heal
        else if (attackThisRound.getEffect().getEffectSoort().contains("Heal")){
            calculateDamage();
            checkHeal();
        }
        //buff
        else if (attackThisRound.getEffect().getEffectSoort().contains("Buff")){
            
        }
    }
    public void checkDamageAll(){
        if (attackThisRound.getEffect().getEffectSoort().equals("Damage All")){
            for (Speler spelertje: Spel.getSpelers()){
                if (attackThisRound.getEffect().getSpecialEffect().equals("Normal")){
                    spelertje.setAmountOfLives(spelertje.getAmountOfLives() - getDamageThisRound());
                }
                else if (attackThisRound.getEffect().getSpecialEffect().equals("Damage Over Time")){
                    spelertje.setAmountOfLives(spelertje.getAmountOfLives() - getDamageThisRound());
                    spelertje.setDamageOverTime(spelertje.getDamageOverTime() + 2);
                }
                else if (attackThisRound.getEffect().getSpecialEffect().equals("Final Hit")){
                    if (spelertje.getAmountOfLives() <= 50){
                        setDamageThisRound(attackThisRound.getWaarde() * 2);
                        spelertje.setAmountOfLives(spelertje.getAmountOfLives() - getDamageThisRound());
                    }
                    else{
                        spelertje.setAmountOfLives(spelertje.getAmountOfLives() - getDamageThisRound());
                    }
                }
                else if (attackThisRound.getEffect().getSpecialEffect().equals("Multi Hit")){
                    for (int i = 0; i < 2; i++){
                        spelertje.setAmountOfLives(spelertje.getAmountOfLives() - getDamageThisRound());
                    }
                }
                else{
                    System.out.println("Damage effect not found.");
                }
                
                if (spelertje.getAmountOfLives() < 0){
                    spelertje.setAmountOfLives(0);
                }
            }
        }
    }
    public void checkDamageOne(){
        if (attackThisRound.getEffect().getEffectSoort().equals("Damage One")){
            if (attackThisRound.getEffect().getSpecialEffect().equals("Normal")){
                    speler.setAmountOfLives(speler.getAmountOfLives() - getDamageThisRound());
            }
            else if (attackThisRound.getEffect().getSpecialEffect().equals("Damage Over Time")){
                speler.setAmountOfLives(speler.getAmountOfLives() - getDamageThisRound());
                speler.setDamageOverTime(speler.getDamageOverTime() + 2);
            }
            else if (attackThisRound.getEffect().getSpecialEffect().equals("Final Hit")){
                if (speler.getAmountOfLives() <= 50){
                    setDamageThisRound(attackThisRound.getWaarde() * 2);
                    speler.setAmountOfLives(speler.getAmountOfLives() - getDamageThisRound());
                }
                else{
                    speler.setAmountOfLives(speler.getAmountOfLives() - getDamageThisRound());
                }
            }
            else if (attackThisRound.getEffect().getSpecialEffect().equals("Multi Hit")){
                for (int i = 0; i < 2; i++){
                    speler.setAmountOfLives(speler.getAmountOfLives() - getDamageThisRound());
                }
            }
            else{
                System.out.println("Damage effect not found.");
            }
            
            if (speler.getAmountOfLives() < 0){
                speler.setAmountOfLives(0);
            }
        }
    }
    public void checkHeal(){
        if (attackThisRound.getEffect().getEffectSoort().equals("Heal Self")){
            setAantalLevens(aantalLevens + getDamageThisRound());
        }
        else if (attackThisRound.getEffect().getEffectSoort().equals("Heal All")){
            for (Vijand vijand: Spel.getVijanden()){
                vijand.setAantalLevens(vijand.getAantalLevens() + getDamageThisRound());
            }
        }
        else{
            System.out.println("Heal effect not found.");
        }
    }
    public void calculateDamage(){
        damageThisRound = (int) Math.round((0.8 + Math.random() * (1.2 - 0.8)) * attackThisRound.getWaarde());
    }
    public void setAantalLevens(int aantalLevens){
        this.aantalLevens = aantalLevens;
    }
    public int getAantalLevens(){
        return aantalLevens;
    }
    public Speler huidigeSpeler(){
        return huidigeSpeler;
    }
    public String getName(){
        return naam;
    }
    public String getEnemyKind(){
        return enemyKind;
    }
    public int calculateCoinDrop(){
        double randomFactor = rnd.nextDouble() * 0.4 + 0.8; // genereert een getal tussen 0.8 en 1.2
        coinDropThisRound = (int) Math.round(baseCoinDrop * randomFactor);
        
        return coinDropThisRound;
    }
    public String determineName(){
        // "James", "Robert", "John", "Michael", "David", "William" | "Mary", "Patricia", "Jennifer", "Linda", "Lisa"
        // bro this method took me so long to write and it finally works
        List<String> possibleNamesArrayList = new ArrayList<>(Arrays.asList(possibleNames));
        
        int choosingNameIndex = rnd.nextInt(possibleNamesArrayList.size());
        naam = possibleNames[choosingNameIndex];
        
        possibleNamesArrayList.subList(choosingNameIndex, choosingNameIndex + 1).clear();
        possibleNames = possibleNamesArrayList.toArray(new String[possibleNamesArrayList.size()]);
        
        return naam;
    }
    public void printDamageThisRound(){
        String playersHit = speler.getName();
        if (attackThisRound.getEffect().getEffectSoort().contains("All")){
            playersHit = " everyone";
        }
        
        if (attackThisRound.getEffect().getEffectSoort().contains("Damage")){
            System.out.println(naam + " (" + getAantalLevens() + " hp)" + " did " + damageThisRound + " damage with his attack " + attackThisRound.getName() + " to " + playersHit + ". ");
        }
        else if (attackThisRound.getEffect().getEffectSoort().contains("Heal")){
            if (playersHit.equals(speler.getName())){
                playersHit = " himself";
            }
            else{
                playersHit = " everyone from his team";
            }
            System.out.println(naam + " (" + getAantalLevens() + " hp) healed" + playersHit + " for " + damageThisRound + ". ");
        }
        else{
            System.out.println(naam + " (" + getAantalLevens() + " hp) did something.");
        }
    }
    public void printBaseCoinDrop(){
        System.out.println(baseCoinDrop);
    }
    public int getDamageOverTime(){
        return damageOverTime;
    }
    public void setDamageOverTime(int value){ //uitgedrukt in hoeveel rondes
        damageOverTime = value;
    }
    public void doDamageOverTime(){
        if (damageOverTime > 0){
            aantalLevens -= 5;
            damageOverTime--;
            if (aantalLevens < 0){
                aantalLevens = 0;
            }
            printDamageOverTime();
        }
    }
    public void printDamageOverTime(){
        if (aantalLevens != 0){
            System.out.println(naam + " got damaged by a DoT effect for 5 damage. (" + aantalLevens + "hp)");
        }
        else{
            System.out.println(naam + " got damaged by a DoT effect for 5 damage. (dead)");
        }
    }
    public static Vijand[] getAllEnemies(){
        return allEnemies;
    }
    public int getBaseCoinDrop(){
        return baseCoinDrop;
    }
    public Aanval[] getAanvallen(){
        return aanvallen;
    }
    public int getDamageThisRound(){
        return damageThisRound;
    }
    public void setDamageThisRound(int value){
        damageThisRound = value;
    }
}