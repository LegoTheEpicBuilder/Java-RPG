import java.util.*;

public class Voorwerp implements Cloneable{
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
        
    protected double weight;
    protected String name;
    protected String rarity;
    protected boolean isUpgraded = false;
    
    protected int averageSellPrice;
    protected int sellPrice;
    
    protected static String[] rarities = {"Common", "Rare", "Epic", "Legendary"};
    protected String[] categoriën;
    
    private Random rnd = new Random();
    private static Random random = new Random();
    
    public Voorwerp(double weight, String name){
        this.weight = weight;
        this.name = name;
    }
    public boolean getIsUpgraded(){
        return isUpgraded;
    }
    public void setIsUpgraded(boolean isUpgraded){
        this.isUpgraded = isUpgraded;
    }
    public static String determineRarity(){
        int chosenRarity = random.nextInt(100) + 1;
        String theRarity;
        
        if (chosenRarity <= 60){
            theRarity = rarities[0];
        }
        else if (chosenRarity <= 85){
            theRarity = rarities[1];
        }
        else if (chosenRarity <= 95){
            theRarity = rarities[2];
        }
        else{
            theRarity = rarities[3];
        }
        //System.out.println(theRarity + "  -  " + chosenRarity);
        return theRarity;
    }
    public void determineAvgSellPrice(){    //avg sell price of attacks is standard 50 coins cheaper than weapons
        int i;
        int priceValue = 100;
        
        for (i = 0; rarities[i] != rarity; i++){
            priceValue += 25;
        }
        
        if (this instanceof Wapen){
            averageSellPrice = priceValue;
            
            if (this.getName().equals("Fists")){
                averageSellPrice = 0;
            }
        }
        else if (this instanceof Aanval){
            averageSellPrice = priceValue - 50;
        }
    }
    
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public double getWeight(){
        return weight;
    }
    public void setWeight(double weight){
        this.weight = weight;
    }
    public String getRarity(){
        return rarity;
    }
    public static String[] getRarities(){
        return rarities;
    }
    public int getAverageSellPrice(){
        return averageSellPrice;
    }
    public int getSellPrice(){
        return sellPrice;
    }
    public void setSellPrice(int sellPrice){
        this.sellPrice = sellPrice;
    }
}