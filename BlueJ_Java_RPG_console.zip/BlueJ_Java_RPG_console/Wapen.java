import java.util.Random;
import java.util.Arrays;
import java.util.*;

public class Wapen extends Voorwerp implements Cloneable
{
    private Aanval chosenAttack;
    private int baseDamage;
    private int damageThisRound;
    private double critChance;
    
    private Aanval[] aanvallen = new Aanval[2]; //amount of attacks the weapon can have can be upgraded (min = 2, max = 4) --> upgradable thru blacksmith?
    
    private static String[] names = {"Fists", "Wooden Club", "Sword", "Knife", "Pistol", "Bow"}; //fists always has to be the first value in this array!!
    private static Wapen[] allWeapons = new Wapen[]{
    new Wapen("Fists", 10, new String[]{"Melee"}, new Aanval[]{Aanval.getAllPlayerAttacks()[0], Aanval.getAllPlayerAttacks()[1]}, 0, "Common"),
    new Wapen("Wooden Club", 20, new String[]{"Melee"}, new Aanval[]{Aanval.getAllPlayerAttacks()[2], Aanval.getAllPlayerAttacks()[3]}, 4, "Common"),
    new Wapen("Sword", 12, new String[]{"Melee"}, new Aanval[]{Aanval.getAllPlayerAttacks()[4], Aanval.getAllPlayerAttacks()[5]}, 3, "Common"),
    new Wapen("Knife", 8, new String[]{"Melee"}, new Aanval[]{Aanval.getAllPlayerAttacks()[6], Aanval.getAllPlayerAttacks()[7]}, 2, "Common"),
    new Wapen("Pistol", 15, new String[]{"Ranged"}, new Aanval[]{Aanval.getAllPlayerAttacks()[8], Aanval.getAllPlayerAttacks()[9]}, 3, "Rare"),
    new Wapen("Bow", 20, new String[]{"Ranged"}, new Aanval[]{Aanval.getAllPlayerAttacks()[10], Aanval.getAllPlayerAttacks()[11]}, 3, "Rare"),
    new Wapen("Medkit", 15, new String[]{"Healing"}, new Aanval[]{Aanval.getAllPlayerAttacks()[12], Aanval.getAllPlayerAttacks()[13]}, 3, "Epic")
    };
    
    static Random rnd = new Random();
    
    public Wapen(String name, double critChance, String[] categoriën, Aanval[] aanvallen, double weight, String rarity){
        super(weight, name);
        
        this.name = name;
        this.critChance = critChance;
        this.categoriën = categoriën;
        this.aanvallen = (Aanval[]) aanvallen.clone();
        this.rarity = rarity;
        this.determineAvgSellPrice();
        
        determineBaseAttacks();
    }
    
    @Override
    public Object clone() throws CloneNotSupportedException {
        Wapen clonedWeapon = (Wapen) super.clone();
        clonedWeapon.aanvallen = this.aanvallen.clone();
        return clonedWeapon;
    }

    
    public void determineBaseAttacks(){
        int i = 0;
        
        for (String weaponName: this.getNames()){
            if (this.getName().equals(weaponName)){
                copySetPlayerAttacks(Aanval.getAllPlayerAttacks(), i);
                return;
            }
            i = i + 2;
        }
    }
    public void copySetPlayerAttacks(Aanval[] attacks, int index) {
        try {
            Aanval clonedAttack1 = attacks[index].clone();
            Aanval clonedAttack2 = attacks[index + 1].clone();
            setBaseAanvallen(clonedAttack1, clonedAttack2);
        } catch (CloneNotSupportedException e) {
            // Handel de CloneNotSupportedException af
        }
    }
    
    public void setCritChance(double critChance){
        this.critChance = critChance;
    }
    public static Wapen getRandomWeaponOfRarity(String rarity){ //kiest een random wapen van alle wapens met die zeldzaamheid.
        ArrayList<Wapen> possibleWeapons = new ArrayList <Wapen>();

        for (Wapen wapen: allWeapons){
            if (wapen.getRarity().equals(rarity)){
                possibleWeapons.add(wapen);
            }
        }
        
        if (possibleWeapons.size() > 0){
            int chosenWeapon = rnd.nextInt(possibleWeapons.size());
            return possibleWeapons.get(chosenWeapon);
        }
        else{
            return allWeapons[6];  //dit moet veranderen
        }
    }
    public static Wapen getRandomWeapon(){
        Wapen chosenWeapon = allWeapons[rnd.nextInt(allWeapons.length)];
        return new Wapen(chosenWeapon.getName(), chosenWeapon.getCritChance(), chosenWeapon.getCategoriën(), chosenWeapon.getAanvallen(), chosenWeapon.getWeight(), chosenWeapon.getRarity());
    }
    public static Wapen getRandomWeaponNoFists(){
        Wapen chosenWeapon = allWeapons[rnd.nextInt(allWeapons.length - 1) + 1];
        return new Wapen(chosenWeapon.getName(), chosenWeapon.getCritChance(), chosenWeapon.getCategoriën(), chosenWeapon.getAanvallen(), chosenWeapon.getWeight(), chosenWeapon.getRarity());
    }
    public int calculateDamageOld(){
        //normal damage
        int maxDmg = baseDamage + 5;
        int minDmg = baseDamage - 5;
        int getal = rnd.nextInt(11);
        
        damageThisRound = 0;
        
        //crit damage
        int getal2 = rnd.nextInt(100) + 1;
        double damageMultiplier = 1;
        
        if (critChance >= getal2){
            damageMultiplier = 1.5;
            System.out.println("Crit!");
        }
        
        if (getal < 5){
            damageThisRound = (int) Math.round((baseDamage - (getal + 1)) * damageMultiplier);
        }
        else if (getal > 5){
            damageThisRound = (int) Math.round((baseDamage + getal - 5) * damageMultiplier);
        }
        else if (getal == 5){
            damageThisRound = (int) Math.round(baseDamage * damageMultiplier);
        }
        
        return damageThisRound;
    }
    public void calculateDamage(){
        double damageMultiplier = 1;
        int getal2 = rnd.nextInt(100) + 1;
        
        if (critChance >= getal2){
            damageMultiplier = 1.5;
            System.out.println("Crit!");
        }
        
        damageThisRound = (int) Math.round((0.8 + Math.random() * (1.2 - 0.8)) * chosenAttack.getWaarde() * damageMultiplier); //damage differenciates 20%
    }
    public int calculateValue(int value){
        return (int) Math.round((0.8 + Math.random() * (1.2 - 0.8)) * value); //value differenciates 20%
    }
    public String getName(){
        return name;
    }
    public static String[] getNames(){
        return names;
    }
    public void setDamageThisRound(int damageThisRound){
        this.damageThisRound = damageThisRound;
    }
    public int getDamageThisRound(){
        return damageThisRound;
    }
    public Aanval[] getAanvallen(){
        return aanvallen;
    }
    public void setBaseAanvallen(Aanval attack1, Aanval attack2){
        aanvallen[0] = attack1;
        aanvallen[1] = attack2;
    }
    public void setBaseAanvallenVijand(int index){
        aanvallen[0] = Aanval.getAllEnemyAttacks()[index];
        aanvallen[1] = Aanval.getAllEnemyAttacks()[index + 1];
    }
    
    //deze methode is niet af
    public void setAttackAllPlayerAttacks(int index, int indexArray){ //eerste parameter voor waar in de array te plaatsen en tweede voor kiezen welke aanval
        try{
            aanvallen[index] = (Aanval) Aanval.getAllPlayerAttacks()[indexArray].clone();
        }
        catch (Exception e){
            System.out.println("Something went wrong in the method setAttack()");
        }
    }
    public void setAanval(int index, Aanval attack){
        aanvallen[index] = attack;
    }
    public void setAanvallen(Aanval[] attacks){
        aanvallen = attacks;
    }
    public void printAttacksFromWeapon(Aanval[] aanvallen){
        int i = 1;
        for (Aanval aanval: aanvallen){
            if (aanval != null){
                System.out.println(i + ": " + aanval.getName());
            }
            else{
                System.out.println(i + ": /");
            }
            i++;
        }
    }
    public void setChosenAttack(Aanval chosenAttack){
        this.chosenAttack = chosenAttack;
    }
    public Aanval getChosenAttack(){
        return chosenAttack;
    }
    public static Wapen[] getAllWeapons(){
        return allWeapons;
    }
    public double getCritChance(){
        return critChance;
    }
    public String[] getCategoriën(){
        return categoriën;
    }
    public static void printAllWeapons(){
        int i = 1;
        System.out.println("\n" + "__________" + "\n" + "Weapons: " + "\n");
        
        for (Wapen wapen: Wapen.getAllWeapons()){
            System.out.println(i + ": " + wapen.getName() + " | Crit chance: " + wapen.getCritChance());
            
            System.out.println("Attacks: ");
            for (Aanval aanval: wapen.getAanvallen()){
                System.out.print(aanval.getName() + "     ");
            }
            System.out.println(); //rare bug fixen
            System.out.println();
            
            System.out.println("Categories: ");
            for (String categorie: wapen.getCategoriën()){
                System.out.print(categorie + "     ");
            }
            System.out.println(); //rare bug fixen
            System.out.println("_____");
            i++;
        }
    }
    public void printAttacksOnWeapon(Wapen wapen){
        int i = 1;
        for (Aanval aanval: wapen.getAanvallen()){
            if (aanval != null){
                System.out.println(i + ": " + aanval.getName());
            }
            else{
                System.out.println(i + ": " + "/");
            }
        }
    }
    public static void printAllPlayerWeapons(int index){
        int i = index;
        for (Speler speler: Spel.getSpelers()){
            System.out.println(i + ": " + speler.getWeapon().getName() + " (" + speler.getName() + ")");
            i++;
        }
    }
}
