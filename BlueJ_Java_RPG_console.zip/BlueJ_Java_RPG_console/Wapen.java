import java.util.Random;

public class Wapen
{
    private String weaponName; //name of weapon
    private String kindOfWeapon; //ranged, melee,...
    private int baseDamage;
    private int damageThisRound;
    private double critChance;
    
    private int averageSellPrice;
    private int sellPrice;
    
    private static String[] weaponNames = {"Wooden Club", "Sword", "Knife"};
    
    Random rnd = new Random();
    public Wapen(String weaponName){
        this.weaponName = weaponName;
        checkWeapon();
    }
    public void checkWeapon(){
        if (weaponName.equals("Wooden Club")){
            baseDamage = 25;
            critChance = 15;
            averageSellPrice = 75;
        }
        if (weaponName.equals("Sword")){
            baseDamage = 35;
            critChance = 5;
            averageSellPrice = 90;
        }
        if (weaponName.equals("Knife")){
            baseDamage = 30;
            critChance = 7;
            averageSellPrice = 75;
        }
        if (weaponName.equals("Fists")){
            baseDamage = 15;
            critChance = 10;
        }
    }
    public int calculateDamage(){
        //normal damage
        int maxDmg = baseDamage + 5;
        int minDmg = baseDamage - 5;
        int getal = rnd.nextInt(11);
        
        damageThisRound = 0;
        
        //crit damage
        int getal2 = rnd.nextInt(100) + 1;
        double damageMultiplier = 1;
        
        if (critChance >= getal2){
            damageMultiplier = 1.5;
            System.out.println("Crit!");
        }
        
        if (getal < 5){
            damageThisRound = (int) Math.round((baseDamage - (getal + 1)) * damageMultiplier);
        }
        else if (getal > 5){
            damageThisRound = (int) Math.round((baseDamage + getal - 5) * damageMultiplier);
        }
        else if (getal == 5){
            damageThisRound = (int) Math.round(baseDamage * damageMultiplier);
        }
        
        return damageThisRound;
    }
    public String getWeaponName(){
        return weaponName;
    }
    public static String[] getWeaponNames(){
        return weaponNames;
    }
    public void setWeapon(String weapon){
        this.weaponName = weapon;
        checkWeapon();
    }
    public void setDamageThisRound(int damageThisRound){
        this.damageThisRound = damageThisRound;
    }
    public int getDamageThisRound(){
        return damageThisRound;
    }
    public int getAverageSellPrice(){
        return averageSellPrice;
    }
    public int getSellPrice(){
        return sellPrice;
    }
    public void setSellPrice(int sellPrice){
        this.sellPrice = sellPrice;
    }
}
