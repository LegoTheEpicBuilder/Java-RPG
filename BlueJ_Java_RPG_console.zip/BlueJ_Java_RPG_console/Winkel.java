import java.util.Random;
import java.util.Scanner;

public class Winkel{
    private static boolean isVisited = false;
    
    private static Wapen[] sellingWeapons;
    private static Aanval[] sellingAttacks;
    private static Winkel currentShop;
    
    private static int[] averageSellPrices = {20, 30, 40, 50};  //common, rare, epic, legendary
    private static int[] chosenSellPrices = new int[4];
    
    private static Random rnd = new Random();
    private static Scanner sc = new Scanner(System.in);
    
    public Winkel(int amountOfWeapons, int amountOfAttacks){
        sellingWeapons = new Wapen[amountOfWeapons];
        sellingAttacks = new Aanval[amountOfAttacks];
    }
    public static void makeChoice(){
        String[] options = {"Buy item(s)", "Sell item(s)", "Go back"};
        String choice;
        
        Spel.setPlayerLocation("Shop");
        System.out.println("What do you wanna do at the shop?");
        
        for (int i = 1; i <= options.length; i++){
            System.out.println(i + ": " + options[i - 1]);
        }
        choice = sc.nextLine();
        
        if (choice.equalsIgnoreCase(options[0]) || choice.equals("1")){
            if (!isVisited){
                isVisited = true;
                currentShop = new Winkel(rnd.nextInt(5) + 4, rnd.nextInt(5) + 4); //makes a shop with 4 - 8 weapons selling in it.
                fillingShop();
                printGreetingBuy();
            }
            else{
                printRegreeting();
            }
            
            buyItem();
            makeChoice();
        }
        else if (choice.equalsIgnoreCase(options[1]) || choice.equals("2")){
            if (!isVisited){
                printGreetingSell();
            }
            else{
                printRegreeting();
            }
            
            sellItem();
            makeChoice();
        }
        else if (choice.equalsIgnoreCase(options[2]) || choice.equals("3")){
            printLeaving();
            Spel.makeChoice();
        }
        else{
            System.out.println("Is not valid input.");
            makeChoice();
        }
    }
    public static void fillingShop(){
        int i = 0;
        
        for (Wapen wapen: sellingWeapons){
            wapen = Wapen.getRandomWeaponOfRarity(Voorwerp.determineRarity());
            calculateSellPrice(wapen);
            sellingWeapons[i] = wapen;
            i++;
        }
        i = 0;
        for (Aanval aanval: sellingAttacks){
            aanval = Aanval.getRandomAttackOfRarity(Voorwerp.determineRarity());
            calculateSellPrice(aanval);
            sellingAttacks[i] = aanval;
            i++;
        }
    }
    public static void printGreetingBuy(){
        System.out.println("Hello! Welcome to my shop!" + "\n" + "Let me show you what I got in store for you this time.");
    }
    public static void printGreetingSell(){
        System.out.println("You say you want to sell some items? Well lucky you, you came to the right place!");
    }
    public static void printRegreeting(){
        int chosenLine = rnd.nextInt(2);
        
        switch (chosenLine){
            case 0: System.out.println("Hello! Welcome again!"); break;
            case 1: System.out.println("Sup! Glad to see you back!"); break;
        }
    }
    public static void printLeaving(){
        System.out.println("Thanks for checking out my store! Hope to see you back sometime.");
    }
    public static void printShop(){
        int i = 0;
        System.out.println("__________" + "\n" + "Shop:");
        System.out.println("Weapons:");
        for (Wapen wapen: sellingWeapons){
            if (wapen != null){
                System.out.println((i + 1) + ": " + wapen.getName() + " (" + wapen.getSellPrice() + " coins)");
            }
            else{
                System.out.println((i + 1) + ": SOLD!");
            }
            i++;
        }
        
        System.out.println("\n" + "Attacks:");
        for (Aanval aanval: sellingAttacks){
            if (aanval != null){
                System.out.println((i + 1) + ": " + aanval.getName() + " (" + aanval.getSellPrice() + " coins)");
            }
            else{
                System.out.println((i + 1) + ": SOLD!");
            }
            i++;
        }
    }
    public static void buyItem(){
        int index = 0;
        boolean buyAnotherItem = false;
        boolean firstTime = true;
        
        Voorwerp chosenItem;
        String itemKind = "";
        
        printShop();
        Rugzak.printCoins();
        System.out.println("Do you wanna buy anything? (Y / N)");
        String answer = sc.nextLine();
        
        if (answer.equalsIgnoreCase("Y") || answer.equalsIgnoreCase("Yes")){
            while (firstTime == true || buyAnotherItem == true){
                firstTime = false;
                buyAnotherItem = false;
                
                System.out.println("What item do you wanna buy? (number)");
                int answer2 = sc.nextInt();
                
                try{
                    if (sellingWeapons.length >= answer2 && answer2 > 0){
                        chosenItem = sellingWeapons[answer2 - 1];
                        itemKind = "weapon";
                    }
                    else if (sellingWeapons.length + sellingAttacks.length >= answer2 && answer2 > 0){
                        chosenItem = sellingAttacks[answer2 - sellingWeapons.length - 1];
                        itemKind = "attack";
                    }
                    else{
                        System.out.println("Item not found.");
                        return;
                    }
                }
                catch (Exception e){
                    System.out.println("Invalid location.");
                    return;
                }
                
                try{
                    while (Rugzak.getCoins() < chosenItem.getSellPrice()){
                        System.out.println("You cannot afford this item. Do you wanna cancel buying an item? (Y / N)");
                        
                        sc.nextLine();
                        String answer3 = sc.nextLine();
                        if (answer3.equalsIgnoreCase("Y") || answer3.equalsIgnoreCase("Yes")){
                            System.out.println("You canceled purchasing an item. Hope to see you back here sometime.");
                            Spel.makeChoice();
                            return;
                        }
                        else if (answer3.equalsIgnoreCase("N") || answer3.equalsIgnoreCase("No")){
                            buyAnotherItem = true;
                            break;
                        }
                    }
                }
                catch (NullPointerException e){
                    System.out.println("That item is already sold out!");
                    sc.nextLine();
                    return;
                }
                
                if(Rugzak.getCoins() >= chosenItem.getSellPrice()){ //if your coins are greater or the same as the price of the item, buy it and store it in your inventory.
                    if (chosenItem instanceof Wapen){
                        if (Rugzak.getMaxWeight() > Rugzak.getTotalWeight() + chosenItem.getWeight()){
                            Rugzak.removeCoins(chosenItem.getSellPrice());
                            Rugzak.getWeapons().add((Wapen) chosenItem);
                            sellingWeapons[answer2 - 1] = null;
                        }
                        else{
                            System.out.println("Canceled buying " + itemKind + ", your backpack is max weight.");
                            return;
                        }
                    }
                    else if (chosenItem instanceof Aanval){
                        if (Rugzak.getMaxWeight() > Rugzak.getTotalWeight() + chosenItem.getWeight()){
                            Rugzak.removeCoins(chosenItem.getSellPrice());
                            Rugzak.getAttacks().add((Aanval) chosenItem);
                            sellingAttacks[answer2 - sellingWeapons.length - 1] = null;
                        }
                        else{
                            System.out.println("Canceled buying weapon, your backpack is max weight.");
                            return;
                        }
                    }
                    else{
                        System.out.println("Kind of item hasn't been found.");
                        return;
                    }
                    
                    System.out.println("You bought the " + itemKind + " " + chosenItem.getName() + ".");
                    System.out.println("Do you wanna buy anything else? (Y / N)");
                    sc.nextLine();
                    String answer4 = sc.nextLine();
                    
                    if(answer4.equalsIgnoreCase("Y") || answer4.equalsIgnoreCase("Yes")){
                        buyAnotherItem = true;
                    }
                }
            }
        }
    }
    public static void generateSellPrices(){
        for (int i = 0; i < averageSellPrices.length; i++){
            double randomFactor = rnd.nextDouble() * 0.4 + 0.8; // genereert een getal tussen 0.8 en 1.2
            chosenSellPrices[i] = (int) Math.round(averageSellPrices[i] * randomFactor);
        }
    }
    public static void sellItem(){  //common, rare, epic, legendary
        int input;
        String input2;
        Voorwerp chosenItem = null;
        boolean sellAnotherItem = true;
        int sellPrice = 0;
        
        generateSellPrices();
        
        //printing today's prices
        System.out.println("Today's prices: ");
        for (int i = 0; i < chosenSellPrices.length; i++){
            System.out.println(Voorwerp.getRarities()[i] + ": " + chosenSellPrices[i] + " coins (average = " + averageSellPrices[i] + ")");
        }
        
        while (sellAnotherItem){
            //start selling
            System.out.println("What do you wanna sell?");
            
            int j = 0;
            
            System.out.println("\n" + "__________" + "\n" + "Your backpack:");
            System.out.println("Your weapons: ");
            
            if (Rugzak.getWeapons().size() == 0){
                System.out.println("none");
            }
            for (Wapen wapen: Rugzak.getWeapons()){
                if (wapen != null){
                    System.out.println((j + 1) + ": " + wapen.getName() + " (" + wapen.getRarity() + ")");
                }
                j++;
            }
            
            System.out.println("\n" + "Your attacks: ");
            if (Rugzak.getAttacks().size() == 0){
                System.out.println("none");
            }
            for (Aanval aanval: Rugzak.getAttacks()){
                System.out.println((j + 1) + ": " + aanval.getName() + " (" + aanval.getRarity() + ")");
                j++;
            }
            input = sc.nextInt();
            
            //locating item
            if (input <= Rugzak.getWeapons().size() && input > 0){
                chosenItem = (Wapen) Rugzak.getWeapons().get(input - 1);
            }
            else if (input - Rugzak.getWeapons().size() <= Rugzak.getAttacks().size() && input > 0){
                chosenItem = (Aanval) Rugzak.getAttacks().get(input - Rugzak.getWeapons().size() - 1);
            }
            else{
                System.out.println("Invalid location given.");
                sc.nextLine();
                return;
            }
            
            //checking weapon rarity & sell price
            for (int i = 0; i < Voorwerp.getRarities().length; i++){
                if (chosenItem.getRarity().equals(Voorwerp.getRarities()[i])){
                    sellPrice = chosenSellPrices[i];
                    break;
                }
            }
            
            //some more checks
            if (sellPrice == 0){
                System.out.println("Sell price not found.");
                sc.nextLine();
                return;
            }
            if (chosenItem == null){
                System.out.println("Item not found.");
                sc.nextLine();
                return;
            }
            
            //selling item
            Rugzak.setCoins(Rugzak.getCoins() + sellPrice);
            
            if (input <= Rugzak.getWeapons().size()){
                Rugzak.getWeapons().remove(input - 1);
                System.out.println("Succesfully sold the weapon " + chosenItem.getName() + " for " + sellPrice + " coins.");
            }
            else{
                Rugzak.getAttacks().remove(input - Rugzak.getWeapons().size() - 1);
                System.out.println("Succesfully sold the attack " + chosenItem.getName() + " for " + sellPrice + " coins.");
            }
            
            //asking if wanna sell another item
            System.out.println("Do you wanna sell another item? Y / N");
            sc.nextLine();
            input2 = sc.nextLine();
            
            if (input2.equalsIgnoreCase("Y") || input2.equalsIgnoreCase("Yes")){
                sellAnotherItem = true;
            }
            else{
                sellAnotherItem = false;
            }
        }
    }
    public static void calculateSellPrice(Voorwerp voorwerp){
        double randomFactor = rnd.nextDouble() * 0.4 + 0.8; // genereert een getal tussen 0.8 en 1.2
        voorwerp.setSellPrice((int) Math.round(voorwerp.getAverageSellPrice() * randomFactor));
    }
}